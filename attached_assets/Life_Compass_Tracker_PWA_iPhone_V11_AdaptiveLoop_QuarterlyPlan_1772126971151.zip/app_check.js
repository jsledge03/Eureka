
(function(){
  const STORAGE_KEY = "life_compass_tracker_v1";
  const now = new Date();
  const YEAR = now.getFullYear();

  const defaultCategories = [
    { id:"physical", name:"Physical", color:"#33d17a", def:"Body, fitness, nutrition, sleep, recovery, health behaviors." , examples:["Lift/strength", "Cardio/steps", "Meal quality", "Sleep routine"]},
    { id:"mental", name:"Mental & Emotional", color:"#7aa2ff", def:"Mood regulation, learning, therapy/reflection, stress skills, cognition." , examples:["Journaling", "Therapy skills", "Study/reading", "Breathwork"]},
    { id:"spiritual", name:"Spiritual", color:"#c6a0ff", def:"Faith, prayer/meditation, meaning, gratitude, inner life, alignment with higher values." , examples:["Prayer", "Meditation", "Scripture", "Contemplation"]},
    { id:"social", name:"Social & Communal", color:"#ffb86b", def:"Relationships, community, service, belonging, connection practices." , examples:["Call family", "Friend meetup", "Mentorship", "Service"]},
    { id:"career", name:"Career & Financial", color:"#ffd86b", def:"Work performance, skill growth, money systems, budgeting/investing, career strategy." , examples:["Deep work", "Cert study", "Budget review", "Networking"]},
    { id:"environmental", name:"Environmental", color:"#66d9ef", def:"Space, organization, cleanliness, nature exposure, environmental supports." , examples:["Room reset", "Meal prep setup", "Outside walk", "Declutter"]},
    { id:"identity", name:"Identity & Purpose", color:"#ff6bd6", def:"Values alignment, integrity, creativity, mission, legacy, self-concept practices." , examples:["Creative work", "Values review", "Personal project", "Purpose planning"]}
  ];

  const uid = () => Math.random().toString(16).slice(2) + "-" + Date.now().toString(16);
  const iso = (d) => d.toISOString().slice(0,10);
  const parseISO = (s) => { const [y,m,dd]=s.split("-").map(Number); return new Date(y, m-1, dd); };
  const startOfYear = (y) => new Date(y,0,1);
  const endOfYear = (y) => new Date(y,11,31);
  const startOfWeek = (d) => { const x=new Date(d); const day=x.getDay(); const diff=(day+6)%7; x.setDate(x.getDate()-diff); x.setHours(0,0,0,0); return x; };
  const weekKey = (d) => iso(startOfWeek(d));
  const clamp = (n,a,b)=> Math.max(a, Math.min(b,n));

  function load(){
    const raw = localStorage.getItem(STORAGE_KEY);
    if(raw){
      try{ return JSON.parse(raw); } catch(e){}
    }
    const g1 = {id:uid(), title:"Build strong, consistent training base", categoryId:"physical", why:"Energy, confidence, healthspan", metric:"4 lifts/week by year-end", desc:"Prioritize progressive overload and recovery. Keep it sustainable."};
    const g2 = {id:uid(), title:"Sharpen emotional regulation & reflection", categoryId:"mental", why:"More grounded leadership", metric:"Journal 4x/week", desc:"Short reflection + one actionable adjustment each week."};
    const h1 = {id:uid(), name:"Lift (Upper/Lower)", categoryId:"physical", schedule:{type:"xweek", value:4}, difficulty:3, goalId:g1.id, notes:"Any split; show up & progress."};
    const h2 = {id:uid(), name:"10 min reflection / journaling", categoryId:"mental", schedule:{type:"days", value:["Mon","Wed","Fri","Sun"]}, difficulty:2, goalId:g2.id, notes:"What helped? What got in the way? Next lever."};
    const h3 = {id:uid(), name:"Prayer / meditation", categoryId:"spiritual", schedule:{type:"daily", value:1}, difficulty:2, goalId:"", notes:"Grounding practice."};

    const data = { version:1, year:YEAR, categories: defaultCategories, goals:[g1,g2], habits:[h1,h2,h3], logs:{}, settings:{ mvd:{ habitsToHit: 4 } } };
    save(data);
    return data;
  }
  function save(data){ localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }

  let state = load();

  // DOM
  const tabs = [...document.querySelectorAll(".tab")];
  const sections = [...document.querySelectorAll(".section")];

  const filterCategory = document.getElementById("filterCategory");
  const yearLabel = document.getElementById("yearLabel");
  const heatmap = document.getElementById("heatmap");
  const kpis = document.getElementById("kpis");
  const mvdNotice = document.getElementById("mvdNotice");
  const todaySub = document.getElementById("todaySub");
  const todayHabits = document.getElementById("todayHabits");

  const goalsList = document.getElementById("goalsList");
  const goalsFilterCategory = document.getElementById("goalsFilterCategory");
  const habitsFilterCategory = document.getElementById("habitsFilterCategory");
  const habitsTable = document.getElementById("habitsTable");

  const insightsWindow = document.getElementById("insightsWindow");
  const insightKpis = document.getElementById("insightKpis");
  const categoryBars = document.getElementById("categoryBars");
  const levers = document.getElementById("levers");
  const categoriesList = document.getElementById("categoriesList");

  const categoryEditor = document.getElementById("categoryEditor");

  // Modals
  window.modalDay = document.getElementById("modalDay");
  window.modalHabit = document.getElementById("modalHabit");
  window.modalGoal = document.getElementById("modalGoal");
  window.modalData = document.getElementById("modalData");

  const modalDayTitle = document.getElementById("modalDayTitle");
  const modalDaySub = document.getElementById("modalDaySub");
  const modalDayHabits = document.getElementById("modalDayHabits");
  const dayNotes = document.getElementById("dayNotes");
  const btnSaveDay = document.getElementById("btnSaveDay");

  const habitModalTitle = document.getElementById("habitModalTitle");
  const habitName = document.getElementById("habitName");
  const habitCategory = document.getElementById("habitCategory");
  const habitScheduleType = document.getElementById("habitScheduleType");
  const habitScheduleValue = document.getElementById("habitScheduleValue");
  const habitScheduleValueLabel = document.getElementById("habitScheduleValueLabel");
  const habitScheduleHelp = document.getElementById("habitScheduleHelp");
  const habitGoal = document.getElementById("habitGoal");
  const habitDifficulty = document.getElementById("habitDifficulty");
  const habitNotes = document.getElementById("habitNotes");
  const btnSaveHabit = document.getElementById("btnSaveHabit");
  const btnDeleteHabit = document.getElementById("btnDeleteHabit");

  const goalModalTitle = document.getElementById("goalModalTitle");
  const goalTitle = document.getElementById("goalTitle");
  const goalCategory = document.getElementById("goalCategory");
  const goalWhy = document.getElementById("goalWhy");
  const goalMetric = document.getElementById("goalMetric");
  const goalDesc = document.getElementById("goalDesc");
  const btnSaveGoal = document.getElementById("btnSaveGoal");
  const btnDeleteGoal = document.getElementById("btnDeleteGoal");

  const dataModalTitle = document.getElementById("dataModalTitle");
  const dataTextarea = document.getElementById("dataTextarea");
  const btnApplyImport = document.getElementById("btnApplyImport");

  const catById = (id)=> state.categories.find(c=>c.id===id);
  const goalById = (id)=> state.goals.find(g=>g.id===id);
  const habitById = (id)=> state.habits.find(h=>h.id===id);

  const fmtDowList = (arr)=> arr.join(", ");

  function habitScheduleLabel(h){
    const t = h.schedule?.type || "daily";
    const v = h.schedule?.value;
    if(t==="daily") return "Daily";
    if(t==="xweek") return (v||1) + "×/week";
    if(t==="days") return "Days: " + fmtDowList(v||[]);
    return "—";
  }

  function isHabitDueOnDate(h, d){
    const t = h.schedule?.type || "daily";
    if(t==="daily") return true;
    if(t==="days"){
      const days = h.schedule?.value || [];
      const map = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
      const day = map[d.getDay()];
      return days.includes(day);
    }
    if(t==="xweek") return true;
    return true;
  }

  function getLog(dateIso){
    state.logs[dateIso] = state.logs[dateIso] || { checks:{}, note:"" };
    return state.logs[dateIso];
  }

  function completionForDate(d, categoryId="all"){
    const dateIso = iso(d);
    const log = state.logs[dateIso];
    const habits = state.habits.filter(h => categoryId==="all" ? true : h.categoryId===categoryId);
    const due = habits.filter(h=>isHabitDueOnDate(h,d));
    if(due.length===0) return {rate:0, done:0, total:0};
    let done=0;
    for(const h of due){ if(log?.checks?.[h.id]) done++; }
    const rate = done / due.length;
    return {rate, done, total: due.length};
  }

  function yearDays(y){
    const out=[];
    const d = startOfYear(y);
    const end = endOfYear(y);
    while(d<=end){ out.push(new Date(d)); d.setDate(d.getDate()+1); }
    return out;
  }

  tabs.forEach(t=> t.addEventListener("click", ()=>{
    const tab = t.dataset.tab;
    tabs.forEach(x=>x.classList.toggle("active", x.dataset.tab===tab));
    sections.forEach(s=>s.classList.toggle("active", s.id===tab));
    render();
  }));

  function fillCategorySelect(sel, includeAll=true){
    const prev = sel.value;
    sel.innerHTML = "";
    if(includeAll){
      const o = document.createElement("option"); o.value="all"; o.textContent="All categories";
      sel.appendChild(o);
    }
    for(const c of state.categories){
      const o = document.createElement("option");
      o.value = c.id;
      o.textContent = c.name;
      sel.appendChild(o);
    }
    if(prev) sel.value = prev;
  }

  function fillGoalSelect(sel){
    const prev = sel.value;
    sel.innerHTML = "";
    const o0 = document.createElement("option"); o0.value=""; o0.textContent="(none)";
    sel.appendChild(o0);
    for(const g of state.goals){
      const c = catById(g.categoryId);
      const o = document.createElement("option");
      o.value = g.id;
      o.textContent = `${g.title} • ${c?c.name:""}`;
      sel.appendChild(o);
    }
    if(prev!==undefined) sel.value = prev;
  }

  function today(){
    const d = new Date();
    d.setHours(0,0,0,0);
    return d;
  }

  let selectedDay = iso(today());

  function openDay(dateIso){
    selectedDay = dateIso;
    const d = parseISO(dateIso);
    modalDayTitle.textContent = `${dateIso}`;
    modalDaySub.textContent = `Week of ${weekKey(d)} • Check off what you did today.`;
    const log = getLog(dateIso);
    dayNotes.value = log.note || "";
    renderDayChecklist(dateIso);
    modalDay.showModal();
  }

  function renderDayChecklist(dateIso){
    const d = parseISO(dateIso);
    const cat = filterCategory.value || "all";
    const habits = state.habits
      .filter(h => cat==="all" ? true : h.categoryId===cat)
      .filter(h => isHabitDueOnDate(h,d))
      .sort((a,b)=> (a.categoryId.localeCompare(b.categoryId) || a.name.localeCompare(b.name)));
    const log = getLog(dateIso);
    modalDayHabits.innerHTML = "";
    if(habits.length===0){
      const div = document.createElement("div");
      div.className="notice";
      div.textContent="No habits scheduled for this day (with current filter).";
      modalDayHabits.appendChild(div);
      return;
    }
    for(const h of habits){
      const c = catById(h.categoryId);
      const checked = !!log.checks[h.id];
      const el = document.createElement("div");
      el.className="item";
      el.innerHTML = `
        <div>
          <h3><span class="dot" style="background:${c?.color||'#7aa2ff'}"></span>${escapeHtml(h.name)}</h3>
          <div class="meta">${escapeHtml(c?.name||"")} • ${escapeHtml(habitScheduleLabel(h))} • Difficulty ${h.difficulty||3}</div>
        </div>
        <div class="right">
          <span class="tag ${t.listId==="work"?"tag-work":t.listId==="personal"?"tag-personal":"tag-neutral"}">${(listById(state,t.listId)?.name||"")}</span>
          <label class="pill" style="display:flex;gap:8px;align-items:center;cursor:pointer">
            <input type="checkbox" ${checked?"checked":""} data-habit="${h.id}" style="transform:translateY(1px)"/>
            Done
          </label>
        </div>
      `;
      modalDayHabits.appendChild(el);
    }
    modalDayHabits.querySelectorAll("input[type=checkbox]").forEach(cb=>{
      cb.addEventListener("change",(e)=>{
        const id = e.target.dataset.habit;
        const log2 = getLog(dateIso);
        if(e.target.checked) log2.checks[id]=true;
        else delete log2.checks[id];
        save(state);
        render();
      });
    });
  }

  btnSaveDay.addEventListener("click", ()=>{
    const log = getLog(selectedDay);
    log.note = dayNotes.value || "";
    save(state);
    modalDay.close();
    render();
  });

  document.getElementById("btnToday").addEventListener("click", ()=> openDay(iso(today())));
  document.getElementById("btnQuickCheck").addEventListener("click", ()=> openDay(iso(today())));

  // Add goal / habit modals
  const openHabitModal = (habitId=null)=>{
    const editing = !!habitId;
    const h = editing ? habitById(habitId) : null;
    habitModalTitle.textContent = editing ? "Edit habit" : "New habit";
    btnDeleteHabit.style.display = editing ? "inline-flex" : "none";
    habitName.value = h?.name || "";
    habitCategory.value = h?.categoryId || (state.categories[0]?.id || "physical");
    habitScheduleType.value = h?.schedule?.type || "daily";
    habitDifficulty.value = String(h?.difficulty || 3);
    habitNotes.value = h?.notes || "";
    fillGoalSelect(habitGoal);
    habitGoal.value = h?.goalId || "";
    updateScheduleInputs();
    if(h?.schedule?.type==="days"){
      habitScheduleValue.value = (h?.schedule?.value || []).join(",");
    } else {
      habitScheduleValue.value = String(h?.schedule?.value ?? (habitScheduleType.value==="xweek" ? 3 : 1));
    }
    btnSaveHabit.onclick = ()=>{
      const name = habitName.value.trim();
      if(!name){ alert("Please name the habit."); return; }
      const catId = habitCategory.value;
      const type = habitScheduleType.value;
      let raw = habitScheduleValue.value.trim();
      let scheduleValue = 1;
      if(type==="days"){
        const parts = raw.split(",").map(s=>s.trim()).filter(Boolean);
        const allowed = new Set(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]);
        const norm = parts.map(p=> p.slice(0,1).toUpperCase()+p.slice(1,3).toLowerCase()).filter(p=>allowed.has(p));
        scheduleValue = norm;
      } else if(type==="xweek"){
        const n = parseInt(raw || "3",10);
        scheduleValue = clamp(isNaN(n)?3:n,1,14);
      } else {
        scheduleValue = 1;
      }
      const payload = {
        id: editing ? h.id : uid(),
        name,
        categoryId: catId,
        schedule: {type, value: scheduleValue},
        difficulty: parseInt(habitDifficulty.value,10) || 3,
        goalId: habitGoal.value || "",
        notes: habitNotes.value || ""
      };
      if(editing){
        const idx = state.habits.findIndex(x=>x.id===h.id);
        state.habits[idx] = payload;
      } else {
        state.habits.push(payload);
      }
      save(state);
      modalHabit.close();
      render();
    };
    btnDeleteHabit.onclick = ()=>{
      if(!editing) return;
      if(!confirm("Delete this habit? Past logs remain, but the habit will be removed from future tracking.")) return;
      state.habits = state.habits.filter(x=>x.id!==h.id);
      for(const day in state.logs){ if(state.logs[day]?.checks?.[h.id]) delete state.logs[day].checks[h.id]; }
      save(state);
      modalHabit.close();
      render();
    };
    modalHabit.showModal();
  };

  const openGoalModal = (goalId=null)=>{
    const editing = !!goalId;
    const g = editing ? goalById(goalId) : null;
    goalModalTitle.textContent = editing ? "Edit goal" : "New goal";
    btnDeleteGoal.style.display = editing ? "inline-flex" : "none";
    goalTitle.value = g?.title || "";
    goalCategory.value = g?.categoryId || (state.categories[0]?.id || "physical");
    goalWhy.value = g?.why || "";
    goalMetric.value = g?.metric || "";
    goalDesc.value = g?.desc || "";
    btnSaveGoal.onclick = ()=>{
      const title = goalTitle.value.trim();
      if(!title){ alert("Please title the goal."); return; }
      const payload = { id: editing ? g.id : uid(), title, categoryId: goalCategory.value, why: goalWhy.value || "", metric: goalMetric.value || "", desc: goalDesc.value || "" };
      if(editing){
        const idx = state.goals.findIndex(x=>x.id===g.id);
        state.goals[idx] = payload;
      } else {
        state.goals.push(payload);
      }
      save(state);
      modalGoal.close();
      render();
    };
    btnDeleteGoal.onclick = ()=>{
      if(!editing) return;
      if(!confirm("Delete this goal? Linked habits remain but will be unlinked.")) return;
      state.goals = state.goals.filter(x=>x.id!==g.id);
      state.habits.forEach(h=>{ if(h.goalId===g.id) h.goalId=""; });
      save(state);
      modalGoal.close();
      render();
    };
    modalGoal.showModal();
  };

  document.getElementById("btnAddHabit").addEventListener("click", ()=> openHabitModal());
  document.getElementById("btnAddHabit2").addEventListener("click", ()=> openHabitModal());
  document.getElementById("btnAddGoal").addEventListener("click", ()=> openGoalModal());
  document.getElementById("btnAddGoal2").addEventListener("click", ()=> openGoalModal());

  habitScheduleType.addEventListener("change", updateScheduleInputs);
  function updateScheduleInputs(){
    const t = habitScheduleType.value;
    if(t==="daily"){
      habitScheduleValueLabel.textContent = "Value";
      habitScheduleValue.placeholder = "1";
      habitScheduleHelp.textContent = "Daily habits are due every day.";
      habitScheduleValue.value = "1";
    } else if(t==="xweek"){
      habitScheduleValueLabel.textContent = "Times per week";
      habitScheduleValue.placeholder = "e.g., 4";
      habitScheduleHelp.textContent = "Flexible: aim to hit this many times in a week.";
    } else if(t==="days"){
      habitScheduleValueLabel.textContent = "Days (comma-separated)";
      habitScheduleValue.placeholder = "Mon,Wed,Fri";
      habitScheduleHelp.textContent = "Use: Mon,Tue,Wed,Thu,Fri,Sat,Sun.";
    }
  }

  // Filters
  filterCategory.addEventListener("change", render);
  goalsFilterCategory.addEventListener("change", render);
  habitsFilterCategory.addEventListener("change", render);
  insightsWindow.addEventListener("change", render);

  // Settings: export/import/reset
  document.getElementById("btnExport").addEventListener("click", ()=>{
    const blob = new Blob([JSON.stringify(state, null, 2)], {type:"application/json"});
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `life-compass-tracker-${state.year}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  });

  document.getElementById("btnImport").addEventListener("click", ()=>{
    dataModalTitle.textContent = "Import data";
    dataTextarea.value = "";
    modalData.showModal();
  });
  btnApplyImport.addEventListener("click", ()=>{
    try{
      const obj = JSON.parse(dataTextarea.value);
      if(!obj || !obj.categories || !obj.habits || !obj.goals || !obj.logs){
        alert("That JSON doesn't look like a valid export.");
        return;
      }
      state = obj;
      save(state);
      modalData.close();
      render();
      alert("Import applied.");
    }catch(e){ alert("Invalid JSON."); }
  });

  document.getElementById("btnReset").addEventListener("click", ()=>{
    if(!confirm("Reset all data? This clears your local tracker.")) return;
    localStorage.removeItem(STORAGE_KEY);
    state = load();
    render();
  });

  function escapeHtml(s){ return (s||"").replace(/[&<>"']/g, m=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[m])); }

  function renderHeatmap(){
    yearLabel.textContent = `${state.year}`;
    heatmap.innerHTML = "";
    const days = yearDays(state.year);
    const first = startOfYear(state.year);
    const pad = first.getDay(); // Sunday=0
    for(let i=0;i<pad;i++){
      const div = document.createElement("div");
      div.className="cell";
      div.style.visibility="hidden";
      heatmap.appendChild(div);
    }
    const cat = filterCategory.value || "all";
    for(const d of days){
      const {rate, done, total} = completionForDate(d, cat);
      let lvl = 0;
      if(total===0){ lvl = 0; }
      else if(rate >= 1){ lvl = 4; }
      else if(rate >= 0.80){ lvl = 3; }
      else if(rate >= 0.50){ lvl = 2; }
      else { lvl = 1; }
      const cell = document.createElement("div");
      cell.className="cell";
      cell.dataset.lvl = String(lvl);
      cell.title = `${iso(d)} • ${done}/${total} complete (${Math.round(rate*100)}%)`;
      cell.addEventListener("click", ()=> openDay(iso(d)));
      heatmap.appendChild(cell);
    }
  }

  function renderKpis(){
    const cat = filterCategory.value || "all";
    const td = today();
    const cToday = completionForDate(td, cat);

    let done7=0,total7=0;
    for(let i=0;i<7;i++){
      const d = new Date(td); d.setDate(d.getDate()-i);
      const c = completionForDate(d, cat);
      done7 += c.done; total7 += c.total;
    }
    const rate7 = total7? done7/total7 : 0;

    let doneY=0,totalY=0;
    for(const d of yearDays(state.year)){
      if(d>td) break;
      const c = completionForDate(d, cat);
      doneY += c.done; totalY += c.total;
    }
    const rateY = totalY? doneY/totalY : 0;

    const mvd = state.settings?.mvd?.habitsToHit ?? 2;
    let streak=0;
    for(let i=0;;i++){
      const d = new Date(td); d.setDate(d.getDate()-i);
      const dateIso = iso(d);
      const log = state.logs[dateIso];
      const done = log ? Object.keys(log.checks||{}).length : 0;
      if(done>=mvd) streak++;
      else break;
    }

    kpis.innerHTML = `
      <div class="box"><b>${cToday.total? Math.round(cToday.rate*100):0}%</b><span>Today completion (${cToday.done}/${cToday.total})</span></div>
      <div class="box"><b>${Math.round(rate7*100)}%</b><span>Last 7 days (${done7}/${total7})</span></div>
      <div class="box"><b>${Math.round(rateY*100)}%</b><span>Year-to-date (${doneY}/${totalY})</span></div>
    `;
    mvdNotice.innerHTML = `<b>Baseline day:</b> hit <span class="mono">${mvd}</span> habits/day to maintain momentum. Current streak: <span class="mono">${streak}</span> day(s).`;
  }

  function renderToday(){
    const d = today();
    todaySub.textContent = `${iso(d)} • tap to check off`;
    const due = state.habits.filter(h=>isHabitDueOnDate(h,d))
      .sort((a,b)=> (a.categoryId.localeCompare(b.categoryId) || a.name.localeCompare(b.name)));
    const log = getLog(iso(d));
    todayHabits.innerHTML = "";
    if(due.length===0){
      todayHabits.innerHTML = `<div class="notice">No habits yet. Add one to start tracking.</div>`;
      return;
    }
    for(const h of due.slice(0,10)){
      const c = catById(h.categoryId);
      const checked = !!log.checks[h.id];
      const g = h.goalId ? goalById(h.goalId) : null;
      const el = document.createElement("div");
      el.className="item";
      el.innerHTML = `
        <div>
          <h3><span class="dot" style="background:${c?.color||'#7aa2ff'}"></span>${escapeHtml(h.name)}</h3>
          <div class="meta">${escapeHtml(c?.name||"")} • ${escapeHtml(habitScheduleLabel(h))}${g?(" • Goal: "+escapeHtml(g.title)):""}</div>
        </div>
        <div class="right">
          <span class="tag ${t.listId==="work"?"tag-work":t.listId==="personal"?"tag-personal":"tag-neutral"}">${(listById(state,t.listId)?.name||"")}</span>
          <button class="btn ghost" data-act="edit" data-id="${h.id}">Edit</button>
          <label class="pill" style="display:flex;gap:8px;align-items:center;cursor:pointer">
            <input type="checkbox" ${checked?"checked":""} data-habit="${h.id}"/>
            Done
          </label>
        </div>
      `;
      todayHabits.appendChild(el);
    }
    if(due.length>10){
      const more = document.createElement("div");
      more.className="notice";
      more.textContent = `Showing 10 of ${due.length} due habits. Open the day modal to see all.`;
      todayHabits.appendChild(more);
    }
    todayHabits.querySelectorAll("input[type=checkbox]").forEach(cb=>{
      cb.addEventListener("change",(e)=>{
        const id = e.target.dataset.habit;
        const log2 = getLog(iso(d));
        if(e.target.checked) log2.checks[id]=true;
        else delete log2.checks[id];
        save(state);
        render();
      });
    });
    todayHabits.querySelectorAll("button[data-act=edit]").forEach(b=>{
      b.addEventListener("click", ()=> openHabitModal(b.dataset.id));
    });
  }

  function renderGoals(){
    fillCategorySelect(goalsFilterCategory,true);
    const cat = goalsFilterCategory.value || "all";
    const goals = state.goals
      .filter(g=> cat==="all" ? true : g.categoryId===cat)
      .sort((a,b)=> a.categoryId.localeCompare(b.categoryId) || a.title.localeCompare(b.title));
    goalsList.innerHTML = "";
    if(goals.length===0){
      goalsList.innerHTML = `<div class="notice">No goals yet. Add one to clarify what your habits are building toward.</div>`;
      return;
    }
    for(const g of goals){
      const c = catById(g.categoryId);
      const linked = state.habits.filter(h=>h.goalId===g.id).length;
      const el = document.createElement("div");
      el.className="item";
      el.innerHTML = `
        <div>
          <h3><span class="dot" style="background:${c?.color||'#7aa2ff'}"></span>${escapeHtml(g.title)}</h3>
          <div class="meta">${escapeHtml(c?.name||"")} • ${escapeHtml(g.why||"")} ${g.metric?("• "+escapeHtml(g.metric)):""}</div>
          <div class="tiny">${escapeHtml(g.desc||"")}</div>
        </div>
        <div class="right">
          <span class="tag ${t.listId==="work"?"tag-work":t.listId==="personal"?"tag-personal":"tag-neutral"}">${(listById(state,t.listId)?.name||"")}</span>
          <span class="tag">${linked} linked habit(s)</span>
          <button class="btn ghost" data-act="edit" data-id="${g.id}">Edit</button>
        </div>
      `;
      goalsList.appendChild(el);
    }
    goalsList.querySelectorAll("button[data-act=edit]").forEach(b=>{
      b.addEventListener("click", ()=> openGoalModal(b.dataset.id));
    });
  }

  function renderHabits(){
    fillCategorySelect(habitsFilterCategory,true);
    const cat = habitsFilterCategory.value || "all";
    const habits = state.habits
      .filter(h=> cat==="all" ? true : h.categoryId===cat)
      .sort((a,b)=> a.categoryId.localeCompare(b.categoryId) || a.name.localeCompare(b.name));
    habitsTable.innerHTML = "";
    if(habits.length===0){
      habitsTable.innerHTML = `<tr><td colspan="5" style="border-radius:12px">No habits yet. Add one to begin tracking.</td></tr>`;
      return;
    }
    for(const h of habits){
      const c = catById(h.categoryId);
      const g = h.goalId ? goalById(h.goalId) : null;
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><b>${escapeHtml(h.name)}</b><div class="tiny">${escapeHtml(h.notes||"")}</div></td>
        <td><span class="dot" style="background:${c?.color||'#7aa2ff'}"></span>${escapeHtml(c?.name||"")}</td>
        <td>${escapeHtml(habitScheduleLabel(h))}</td>
        <td>${g?escapeHtml(g.title):"<span class='tiny'>(none)</span>"}</td>
        <td style="text-align:right">
          <button class="btn ghost" data-id="${h.id}">Edit</button>
        </td>
      `;
      habitsTable.appendChild(tr);
    }
    habitsTable.querySelectorAll("button").forEach(b=>{
      b.addEventListener("click", ()=> openHabitModal(b.dataset.id));
    });
  }

  function renderInsights(){
    categoriesList.innerHTML = "";
    for(const c of state.categories){
      const el = document.createElement("div");
      el.className="item";
      el.innerHTML = `
        <div>
          <h3><span class="dot" style="background:${c.color}"></span>${escapeHtml(c.name)}</h3>
          <div class="meta">${escapeHtml(c.def)}</div>
          <div class="tiny">Examples: ${escapeHtml((c.examples||[]).join(" • "))}</div>
        </div>
        <div class="right">
          <span class="tag ${t.listId==="work"?"tag-work":t.listId==="personal"?"tag-personal":"tag-neutral"}">${(listById(state,t.listId)?.name||"")}</span><span class="tag mono">${c.id}</span></div>
      `;
      categoriesList.appendChild(el);
    }

    const windowDays = parseInt(insightsWindow.value,10) || 28;
    const end = today();
    const start = new Date(end); start.setDate(start.getDate()-(windowDays-1));

    let done=0,total=0;
    const byDow = Array.from({length:7}, ()=>({done:0,total:0}));
    const byCat = {}; state.categories.forEach(c=> byCat[c.id] = {done:0,total:0});
    const missedDays = [];

    for(let i=0;i<windowDays;i++){
      const d = new Date(start); d.setDate(start.getDate()+i);
      const dateIso = iso(d);
      const dayIndex = d.getDay();

      for(const c of state.categories){
        const comp = completionForDate(d, c.id);
        byCat[c.id].done += comp.done; byCat[c.id].total += comp.total;
      }
      const compAll = completionForDate(d, "all");
      done += compAll.done; total += compAll.total;
      byDow[dayIndex].done += compAll.done; byDow[dayIndex].total += compAll.total;

      if(compAll.total>0 && compAll.done/compAll.total < 0.3) missedDays.push(dateIso);
    }

    const rate = total? done/total : 0;
    const dowNames = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
    const dowRates = byDow.map((x,i)=>({i, rate: x.total? x.done/x.total : -1})).sort((a,b)=>b.rate-a.rate);
    const best = dowRates[0]?.rate>=0 ? dowNames[dowRates[0].i] : "—";
    const worst = dowRates[dowRates.length-1]?.rate>=0 ? dowNames[dowRates[dowRates.length-1].i] : "—";

    const activeHabits = state.habits.length;
    const mvd = state.settings?.mvd?.habitsToHit ?? 2;

    insightKpis.innerHTML = `
      <div class="box"><b>${Math.round(rate*100)}%</b><span>Completion rate (${done}/${total})</span></div>
      <div class="box"><b>${best}</b><span>Best day of week</span></div>
      <div class="box"><b>${worst}</b><span>Hardest day of week</span></div>
    `;

    categoryBars.innerHTML = "";
    for(const c of state.categories){
      const x = byCat[c.id];
      const r = x.total ? x.done/x.total : 0;
      const bar = document.createElement("div");
      bar.style.marginBottom="10px";
      bar.innerHTML = `
        <div class="row space">
          <div class="tiny"><span class="dot" style="background:${c.color}"></span>${escapeHtml(c.name)}</div>
          <div class="tiny mono">${x.done}/${x.total} • ${Math.round(r*100)}%</div>
        </div>
        <div style="height:10px;border-radius:999px;background: rgba(33,48,71,.35); border:1px solid rgba(33,48,71,.6); overflow:hidden">
          <div style="height:10px;width:${Math.round(r*100)}%; background:${c.color}; opacity:.85"></div>
        </div>
      `;
      categoryBars.appendChild(bar);
    }

    levers.innerHTML = "";
    const leverItems = [];
    if(activeHabits > 10) leverItems.push({ title:"Reduce complexity", body:`You have ${activeHabits} habits. Consider pausing 2–4 and keeping a smaller “core stack” for 2 weeks.`});
    if(missedDays.length > Math.max(3, windowDays*0.2)) leverItems.push({ title:"Design a baseline day", body:`Protect momentum by committing to ${mvd} habits/day even on hard days (e.g., 10 minutes each).`});
    if(rate < 0.45) leverItems.push({ title:"Switch to fewer, stronger anchors", body:`Pick 1 anchor habit per priority category and make everything else optional for 14 days.`});
    if(rate >= 0.70) leverItems.push({ title:"Add one small stretch goal", body:"Your consistency is strong. Add 1 low-friction habit (difficulty 1–2) to compound results."});
    if(leverItems.length===0) leverItems.push({ title:"Keep the system steady", body:"You’re in a stable range. Focus on trend consistency and small weekly tweaks."});

    for(const li of leverItems){
      const el = document.createElement("div");
      el.className="item";
      el.innerHTML = `<div><h3>${escapeHtml(li.title)}</h3><div class="meta">${escapeHtml(li.body)}</div></div><div class="right">
          <span class="tag ${t.listId==="work"?"tag-work":t.listId==="personal"?"tag-personal":"tag-neutral"}">${(listById(state,t.listId)?.name||"")}</span><span class="tag">lever</span></div>`;
      levers.appendChild(el);
    }
  }

  function renderSettings(){
    categoryEditor.innerHTML = "";
    for(const c of state.categories){
      const el = document.createElement("div");
      el.className="item";
      el.innerHTML = `
        <div style="width:100%">
          <div class="row space">
            <div class="row" style="gap:8px">
              <span class="dot" style="background:${c.color}"></span>
              <b>${escapeHtml(c.name)}</b>
              <span class="tag mono">${c.id}</span>
            </div>
            <button class="btn ghost" data-id="${c.id}">Edit</button>
          </div>
          <div class="meta">${escapeHtml(c.def)}</div>
        </div>
      `;
      categoryEditor.appendChild(el);
    }
    categoryEditor.querySelectorAll("button").forEach(b=>{
      b.addEventListener("click", ()=>{
        const c = catById(b.dataset.id);
        const name = prompt("Category name:", c.name); if(name===null) return;
        const def = prompt("Definition:", c.def); if(def===null) return;
        const ex = prompt("Examples (separate with • or commas):", (c.examples||[]).join(", "));
        const color = prompt("Color (hex):", c.color);
        c.name = name.trim() || c.name;
        c.def = def.trim() || c.def;
        c.examples = (ex||"").split(/[•,]/).map(s=>s.trim()).filter(Boolean).slice(0,8);
        c.color = (color||c.color).trim() || c.color;
        save(state);
        render();
      });
    });
  }

  function render(){
    fillCategorySelect(filterCategory,true);
    fillCategorySelect(goalsFilterCategory,true);
    fillCategorySelect(habitsFilterCategory,true);
    fillCategorySelect(habitCategory,false);
    fillCategorySelect(goalCategory,false);
    fillGoalSelect(habitGoal);

    renderHeatmap();
    renderKpis();
    renderToday();
    renderGoals();
    renderHabits();
    renderInsights();
    renderSettings();
  }

  // wire add buttons
  function initButtons(){
    document.getElementById("btnAddHabit").addEventListener("click", ()=> openHabitModal());
    document.getElementById("btnAddHabit2").addEventListener("click", ()=> openHabitModal());
    document.getElementById("btnAddGoal").addEventListener("click", ()=> openGoalModal());
    document.getElementById("btnAddGoal2").addEventListener("click", ()=> openGoalModal());
  }
  // prevent double-binding if rerender called (buttons already bound above) - noop

  // initial render
  render();

  // expose helper
  window.LCT = { getState: ()=>state, setState: (s)=>{state=s; save(state); render();}, openDay };
})();



(function(){
  // Add-on modules: Weekly/Annual Review + Coach Mode + GPT Packet export
  const $ = (id)=>document.getElementById(id);
  const modalWeeklyReview = $("modalWeeklyReview");
  const modalMonthlyReview = $("modalMonthlyReview");
  const modalQuarterlyReview = $("modalQuarterlyReview");
  const modalGPTPacket = $("modalGPTPacket");

  const reviewWeek = $("reviewWeek");
  const weeklySummary = $("weeklySummary");

  function iso(d){ return d.toISOString().slice(0,10); }
  function parseISO(s){ const [y,m,dd]=s.split("-").map(Number); return new Date(y, m-1, dd); }
  function startOfWeek(d){
    const x=new Date(d); const day=x.getDay(); const diff=(day+6)%7; x.setDate(x.getDate()-diff);
    x.setHours(0,0,0,0); return x;
  }
  function clamp(n,a,b){ return Math.max(a, Math.min(b,n)); }

  function ensureReviews(state){
    state.reviews = state.reviews || { weekly:{}, annual:{} };
    state.reviews.weekly = state.reviews.weekly || {};
    state.reviews.annual = state.reviews.annual || {};
    return state;
  }

  function getWeekOptions(state, weeksBack=52){
    const today = new Date(); today.setHours(0,0,0,0);
    const start = startOfWeek(today);
    const opts=[];
    for(let i=0;i<weeksBack;i++){
      const d=new Date(start); d.setDate(d.getDate()-7*i);
      const k=iso(d);
      opts.push(k);
    }
    // also include any older keys present
    for(const k of Object.keys(state.reviews.weekly||{})){
      if(!opts.includes(k)) opts.push(k);
    }
    opts.sort((a,b)=> b.localeCompare(a));
    return opts;
  }

  function computeWindowStats(state, startIso, endIso){
    // inclusive start, inclusive end
    const start = parseISO(startIso);
    const end = parseISO(endIso);
    let done=0,total=0;
    const byCat = {};
    state.categories.forEach(c=> byCat[c.id]={done:0,total:0, name:c.name, color:c.color});
    for(let d=new Date(start); d<=end; d.setDate(d.getDate()+1)){
      const dateIso = iso(d);
      const log = state.logs?.[dateIso];
      for(const c of state.categories){
        const habits = state.habits.filter(h=>h.categoryId===c.id).filter(h=>{
          const t=h.schedule?.type||"daily";
          if(t==="daily") return true;
          if(t==="days"){
            const map=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
            const day=map[d.getDay()];
            return (h.schedule?.value||[]).includes(day);
          }
          if(t==="xweek") return true;
          return true;
        });
        const due = habits;
        if(due.length){
          let dDone=0;
          for(const h of due){ if(log?.checks?.[h.id]) dDone++; }
          byCat[c.id].done += dDone;
          byCat[c.id].total += due.length;
        }
      }
      // all categories
      const habitsAll = state.habits.filter(h=>{
        const t=h.schedule?.type||"daily";
        if(t==="daily") return true;
        if(t==="days"){
          const map=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
          const day=map[d.getDay()];
          return (h.schedule?.value||[]).includes(day);
        }
        if(t==="xweek") return true;
        return true;
      });
      if(habitsAll.length){
        let dDone=0;
        for(const h of habitsAll){ if(log?.checks?.[h.id]) dDone++; }
        done += dDone;
        total += habitsAll.length;
      }
    }
    const rate = total ? done/total : 0;
    return {done,total,rate,byCat};
  }

  function latestWeeklyInputs(state){
    const keys = Object.keys(state.reviews.weekly||{}).sort().reverse();
    for(const k of keys){
      const w = state.reviews.weekly[k];
      if(w && (w.sleep || w.stress || w.energy || w.complexity)) return w;
    }
    return null;
  }

  function scoreCoach(state){
    // proxy scoring using available data + latest weekly inputs
    const today = new Date(); today.setHours(0,0,0,0);
    const endIso = iso(today);
    const start28 = new Date(today); start28.setDate(start28.getDate()-27);
    const stats28 = computeWindowStats(state, iso(start28), endIso);

    const activeHabits = state.habits.length;
    const mvd = state.settings?.mvd?.habitsToHit ?? 2;

    // APS: adherence probability proxy
    // start at 5; boost if rate high and complexity moderate; penalize if many habits or low rate.
    let APS = 5;
    if(stats28.rate >= 0.7) APS += 2;
    else if(stats28.rate >= 0.55) APS += 1;
    else if(stats28.rate < 0.4) APS -= 2;
    if(activeHabits > 12) APS -= 2;
    else if(activeHabits > 9) APS -= 1;
    // weekly subjective inputs
    const w = latestWeeklyInputs(state);
    if(w){
      const complexity = Number(w.complexity ?? "");
      if(!Number.isNaN(complexity)){
        if(complexity >= 7) APS -= 1;
        if(complexity <= 3) APS += 1;
      }
    }
    APS = clamp(APS,0,10);

    // RSS: recovery strain proxy (sleep + stress + fatigue)
    let RSS = 0;
    if(w){
      const sleep = Number(w.sleep ?? "");
      const stress = Number(w.stress ?? "");
      const energy = Number(w.energy ?? "");
      if(!Number.isNaN(sleep)){
        if(sleep < 6) RSS += 2;
        else if(sleep < 7) RSS += 1;
      }
      if(!Number.isNaN(stress)){
        if(stress >= 8) RSS += 2;
        else if(stress >= 5) RSS += 1;
      }
      if(!Number.isNaN(energy)){
        if(energy <= 3) RSS += 2;
        else if(energy <= 5) RSS += 1;
      }
    } else {
      // fallback: use low adherence as possible strain
      if(stats28.rate < 0.45) RSS += 2;
    }
    // add life constraint proxy from habit count
    if(activeHabits > 12) RSS += 1;
    RSS = clamp(RSS,0,10);

    // UFR/OOR: proxy if adherence low + strain high
    let UFR = 0;
    if(RSS >= 7) UFR += 2;
    if(stats28.rate < 0.4) UFR += 2;
    if(activeHabits >= 12) UFR += 1;
    UFR = clamp(UFR,0,8);

    let OOR = 0;
    if(RSS >= 7) OOR += 2;
    if(activeHabits >= 14) OOR += 2;
    if(stats28.rate < 0.35) OOR += 1;
    OOR = clamp(OOR,0,8);

    // SRS: unknown medically -> default 0 (user should self-report elsewhere)
    const SRS = 0;

    // Complexity budget
    const CB = clamp(Math.floor(APS/2),1,5);

    return {SRS,RSS,APS,UFR,OOR,CB,stats28,activeHabits,mvd};
  }

  function coachGuidanceFromScores(scores){
    const items=[];
    const {RSS,APS,UFR,OOR,CB,stats28,activeHabits,mvd} = scores;

    // Primary guidance
    if(RSS >= 7 || UFR >= 5 || OOR >= 5){
      items.push({
        title:"Recovery-first week",
        body:`Signals suggest higher strain. For 7–14 days: simplify the plan, reduce intensity/volume, and protect sleep. Keep momentum with a baseline day of ${mvd} habits.`,
        tag:"recovery"
      });
    } else if(APS <= 4){
      items.push({
        title:"Simplify for adherence",
        body:`Your consistency is the bottleneck. Set Complexity = ${CB}. Keep 3–6 core habits, make the rest optional, and increase environment support.`,
        tag:"adherence"
      });
    } else if(stats28.rate >= 0.7){
      items.push({
        title:"You can add a small stretch",
        body:`Your trend is strong (~${Math.round(stats28.rate*100)}% over 28 days). Add 1 low-friction habit or slightly increase an existing target.`,
        tag:"progress"
      });
    } else {
      items.push({
        title:"Tighten anchors",
        body:`Aim for clear anchors: one habit per priority category, and a repeatable baseline day (${mvd} habits). Improve consistency before adding complexity.`,
        tag:"anchors"
      });
    }

    // Secondary levers
    if(activeHabits > 10){
      items.push({
        title:"Reduce habit count",
        body:`You have ${activeHabits} habits. Consider pausing 2–4 for two weeks and tracking only what matters most.`,
        tag:"complexity"
      });
    }
    if(stats28.rate < 0.45){
      items.push({
        title:"Design your environment",
        body:"Lower friction: prep defaults, set cues, pre-commit time blocks, and remove triggers that create missed days.",
        tag:"environment"
      });
    }
    items.push({
      title:"Weekly review cadence",
      body:"Do one 10–15 minute weekly review: Reality → Meaning → Levers → Commit. Then run the plan for 7 days with no over-correction.",
      tag:"process"
    });

    return items;
  }



  function openCoachOverlay(){
    const state = ensureBaseline(ensureAlchemy(ensureReviews(window.LCT.getState())));
    const scores = scoreCoach(state);
    const guidance = coachGuidanceFromScores(scores);
    const top = buildTopActions(state, scores);
    const topEl = $("coachTopActions");
    if(topEl){
      topEl.innerHTML="";
      for(const a of top){
        const div=document.createElement("div");
        div.className="item";
        div.innerHTML = `<div><h3>${a.title}</h3><div class="meta">${a.body}</div></div><div class="right"><span class="tag">next</span></div>`;
        topEl.appendChild(div);
      }
    }

    const planTxt = buildCoachPlan(state, scores);

    const sEl = $("coachOverlayScores");
    if(sEl){
      sEl.innerHTML = `
        <div class="box"><b>${scores.APS}/10</b><span>Adherence</span></div>
        <div class="box"><b>${scores.RSS}/10</b><span>Recovery strain</span></div>
        <div class="box"><b>${state.settings.mvd.habitsToHit ?? 4}</b><span>Baseline day</span></div>
      `;
    }

    const gEl = $("coachOverlayGuidance");
    if(gEl){
      gEl.innerHTML = "";
      // Reframe guidance into OS levers
      const headers = {
        recovery: "Energy (recovery)",
        adherence: "Structure (adherence)",
        complexity: "Environment (friction)",
        environment: "Environment (design)",
        process: "Structure (cadence)",
        anchors: "Structure (anchors)",
        progress: "Meaning (stretch)"
      };
      for(const g of guidance){
        const lever = headers[g.tag] || "System lever";
        const div=document.createElement("div");
        div.className="item";
        div.innerHTML = `<div><h3>${lever}: ${g.title}</h3><div class="meta">${g.body}</div></div><div class="right"><span class="tag">${g.tag}</span></div>`;
        gEl.appendChild(div);
      }
    }

    const pEl = $("coachOverlayPlan");
    if(pEl){
      pEl.innerHTML = `<pre style="white-space:pre-wrap;margin:0">${planTxt.replace(/</g,"&lt;")}</pre>`;
    }

    $("btnCoachOverlayCopy")?.addEventListener("click", ()=>{
      const txt = [
        `Baseline day: ${state.settings.mvd.habitsToHit ?? 4}`,
        `APS: ${scores.APS}/10 • RSS: ${scores.RSS}/10`,
        "",
        ...guidance.map(x=>`- ${x.title}: ${x.body}`),
        "",
        planTxt
      ].join("\n");
      setClipboard(txt);
      alert("Copied.");
    });

    $("btnCoachOverlayGo")?.addEventListener("click", ()=>{
      modalCoachOverlay.close();
      activateTab("coach");
      window.scrollTo({top:0, behavior:"smooth"});
    });

    $("modalCoachOverlay")?.showModal();
  }



  function buildTopActions(state, scores){
    const actions = [];
    const baseline = state.settings?.mvd?.habitsToHit ?? 4;
    // 1) Baseline lock
    actions.push({title:`Hit your baseline (${baseline} habits)`, body:"Protect the baseline day first. If you do nothing else, hit the baseline."});

    // 2) Highest leverage fix
    if(scores.RSS >= 7){
      actions.push({title:"Choose a recovery week", body:"Lower intensity/volume. Earlier bedtime 30–60 min. Keep meals simple and repeatable."});
    } else if(scores.APS <= 4 || scores.CB >= 4){
      actions.push({title:"Reduce complexity", body:"Pause 2–4 habits for 7 days. Keep only anchors + baseline. Make the week easier, not harder."});
    } else {
      actions.push({title:"Add one small stretch", body:"Pick one habit to increase by 5–10% OR add one low-friction bonus habit."});
    }

    // 3) Environment cue
    actions.push({title:"Design the next action", body:"Put the next action in sight (clothes/shoes/water). Remove the top trigger that derails you."});

    return actions.slice(0,3);
  }


  function buildCoachPlan(state, scores){
    // Simple 7-day plan based on bottleneck: recovery vs adherence vs progress
    const mvd = scores.mvd;
    const rate = scores.stats28.rate;
    const active = scores.activeHabits;
    const plan = [];
    const today = new Date(); today.setHours(0,0,0,0);
    const weekStart = startOfWeek(today);
    const weekEnd = new Date(weekStart); weekEnd.setDate(weekEnd.getDate()+6);

    const primary = (scores.RSS>=7 || scores.UFR>=5 || scores.OOR>=5) ? "recovery"
                  : (scores.APS<=4 || rate<0.5) ? "adherence"
                  : "progress";

    plan.push(`Primary focus: **${primary.toUpperCase()}**`);
    if(primary==="recovery"){
      plan.push(`- Keep your Baseline Day: **${mvd} habits/day**.`);
      plan.push(`- Reduce intensity/volume (if training): keep sessions easy-moderate, avoid “all-out” days.`);
      plan.push(`- Prioritize sleep and simple nutrition defaults.`);
    } else if(primary==="adherence"){
      plan.push(`- Complexity: **${scores.CB}/5** → run a simpler week.`);
      plan.push(`- Keep only **3–6 core habits**; pause the rest temporarily.`);
      plan.push(`- Lock in 2 anchors: morning + evening (or lunch + evening).`);
    } else {
      plan.push(`- Trend is solid (~${Math.round(rate*100)}% in last 28 days). Add one small stretch.`);
      plan.push(`- Keep the baseline stable, then add +1 low-friction habit or increase an existing target by 5–10%.`);
    }

    if(active>12){
      plan.push(`- You have **${active} habits**. Consider pausing 2–4 for this week.`);
    }

    plan.push("");
    plan.push("Daily structure:");
    plan.push(`- **Baseline:** hit at least ${mvd} habits.`);
    plan.push("- **If energy is good:** add 1 bonus habit.");
    plan.push("- **If energy is low:** do the easiest version (2-minute rule) and stop.");

    plan.push("");
    plan.push(`Week window: ${iso(weekStart)} → ${iso(weekEnd)}.`);
    return plan.join("\n");
  }

  function updateBadges(state){
    // To-Do badge: number of open tasks due today or overdue, else open tasks in current list.
    const today = (function(){ const d=new Date(); d.setHours(0,0,0,0); return iso(d); })();
    const todos = state.todos;
    let dueCount = 0;
    if(todos && Array.isArray(todos.tasks)){
      for(const t of todos.tasks){
        if(t.done) continue;
        if(t.due && t.due <= today) dueCount++;
      }
    }
    const todoBadge = document.querySelector('[data-badge="todo"]');
    if(todoBadge){
      if(dueCount>0){
        todoBadge.style.display="inline-flex";
        todoBadge.classList.remove("muted");
        todoBadge.classList.add("hot");
        todoBadge.textContent=String(dueCount);
      } else {
        todoBadge.style.display="none";
        todoBadge.textContent="";
      }
    }

    // Review badge: if weekly review not completed for current week, show dot "1"
    const reviewBadge = document.querySelector('[data-badge="review"]');
    if(reviewBadge){
      const wk = iso(startOfWeek(new Date()));
      const has = !!(state.reviews?.weekly?.[wk] && (state.reviews.weekly[wk].updatedAt || state.reviews.weekly[wk].reality || state.reviews.weekly[wk].commit));
      if(!has){
        reviewBadge.style.display="inline-flex";
        reviewBadge.classList.add("muted");
        reviewBadge.classList.remove("hot");
        reviewBadge.textContent="1";
      } else {
        reviewBadge.style.display="none";
        reviewBadge.textContent="";
      }
    }
  }


  function markdownPacket(state){
    const scores = scoreCoach(state);
    const today = new Date(); today.setHours(0,0,0,0);
    const endIso = iso(today);
    const start28 = new Date(today); start28.setDate(start28.getDate()-27);
    const stats28 = scores.stats28;
    const topCats = Object.values(stats28.byCat)
      .filter(x=>x.total>0)
      .map(x=>({name:x.name, rate: x.done/x.total, done:x.done, total:x.total}))
      .sort((a,b)=>b.rate-a.rate);

    const latestWeekKey = (Object.keys(state.reviews.weekly||{}).sort().reverse()[0]) || null;
    const latestWeekly = latestWeekKey ? state.reviews.weekly[latestWeekKey] : null;

    const annual = state.reviews.annual?.[String(state.year)] || null;

    const lines=[];
    lines.push(`# Life Compass Reflection Packet`);
    lines.push(`- Date generated: ${endIso}`);
    lines.push(`- Year: ${state.year}`);
    lines.push("");
    lines.push(`## Snapshot (last 28 days)`);
    lines.push(`- Completion rate: **${Math.round(stats28.rate*100)}%** (${stats28.done}/${stats28.total})`);
    lines.push(`- Active habits: **${scores.activeHabits}**`);
    lines.push(`- Baseline day: **${scores.mvd} habits/day**`);
    lines.push("");
    lines.push(`### Category adherence (28 days)`);
    for(const c of topCats){
      lines.push(`- ${c.name}: ${Math.round(c.rate*100)}% (${c.done}/${c.total})`);
    }
    lines.push("");
    lines.push(`## Current goals`);
    if(!state.goals.length) lines.push(`- (none)`);
    for(const g of state.goals){
      const cat = state.categories.find(c=>c.id===g.categoryId);
      lines.push(`- **${g.title}** (${cat?cat.name:""}) — Why: ${g.why||"(n/a)"} — Metric: ${g.metric||"(n/a)"}`);
    }
    lines.push("");
    lines.push(`## Current habits`);
    if(!state.habits.length) lines.push(`- (none)`);
    for(const h of state.habits){
      const cat = state.categories.find(c=>c.id===h.categoryId);
      const goal = h.goalId ? state.goals.find(g=>g.id===h.goalId) : null;
      const schedule = (h.schedule?.type==="daily") ? "Daily" :
                       (h.schedule?.type==="xweek") ? `${h.schedule?.value||1}x/week` :
                       (h.schedule?.type==="days") ? `Days: ${(h.schedule?.value||[]).join(",")}` : "—";
      lines.push(`- ${h.name} — ${cat?cat.name:""} — ${schedule} — Difficulty ${h.difficulty||3}${goal?` — Goal: ${goal.title}`:""}`);
    }
    lines.push("");
    lines.push(`## Coach calibration (proxy scores)`);
    lines.push(`- APS (adherence): ${scores.APS}/10`);
    lines.push(`- RSS (recovery strain): ${scores.RSS}/10`);
    lines.push(`- UFR (under-fueling risk proxy): ${scores.UFR}/8`);
    lines.push(`- OOR (overuse risk proxy): ${scores.OOR}/8`);
    lines.push(`- Complexity (CB): ${scores.CB}/5`);
    lines.push("");
    if(latestWeekly){
      lines.push(`## Latest weekly review (${latestWeekKey})`);
      if(latestWeekly.sleep || latestWeekly.stress || latestWeekly.energy || latestWeekly.complexity){
        lines.push(`- Sleep avg: ${latestWeekly.sleep||"(n/a)"}h • Stress: ${latestWeekly.stress||"(n/a)"}/10 • Energy: ${latestWeekly.energy||"(n/a)"}/10 • Complexity: ${latestWeekly.complexity||"(n/a)"}/10`);
      }
      if(latestWeekly.reality) lines.push(`- Reality: ${latestWeekly.reality}`);
      if(latestWeekly.meaning) lines.push(`- Meaning: ${latestWeekly.meaning}`);
      if(latestWeekly.levers) lines.push(`- Levers: ${latestWeekly.levers}`);
      if(latestWeekly.commit) lines.push(`- Commit: ${latestWeekly.commit}`);
      lines.push("");
    }
    if(annual){
      lines.push(`## Annual review (${state.year})`);
      lines.push(`- Story: ${annual.story||""}`);
      lines.push(`- Wins: ${annual.wins||""}`);
      lines.push(`- Costs: ${annual.costs||""}`);
      lines.push(`- Lessons: ${annual.lessons||""}`);
      lines.push(`- Next: ${annual.next||""}`);
      lines.push("");
    }

    lines.push(`## What I want from you (Custom GPT)`);
    lines.push(`Use your routing matrix + coaching logic to:`);
    lines.push(`1) Diagnose my biggest bottleneck (adherence vs recovery vs complexity).`);
    lines.push(`2) Propose a 7-day plan aligned with my MECE categories and my baseline day.`);
    lines.push(`3) Suggest 1–3 system levers (environment, schedule, food defaults, workout structure).`);
    lines.push(`4) Provide a short reflection prompt set for the next weekly review.`);
    lines.push("");
    return lines.join("\n");
  }

  function setClipboard(text){
    navigator.clipboard?.writeText(text).catch(()=>{
      // fallback
      const ta=document.createElement("textarea");
      ta.value=text; document.body.appendChild(ta);
      ta.select(); document.execCommand("copy");
      ta.remove();
    });
  }

  function renderReviewTab(){
    const state = ensureReviews(window.LCT.getState());
    // populate week dropdown
    const prev = reviewWeek.value;
    reviewWeek.innerHTML = "";
    const weeks = getWeekOptions(state, 52);
    for(const k of weeks){
      const opt=document.createElement("option");
      opt.value=k;
      opt.textContent=`Week of ${k}`;
      reviewWeek.appendChild(opt);
    }
    if(prev && weeks.includes(prev)) reviewWeek.value = prev;

    // show summary for selected week
    const weekStart = reviewWeek.value || weeks[0];
    if(weekStart){
      const start = parseISO(weekStart);
      const end = new Date(start); end.setDate(end.getDate()+6);
      const stats = computeWindowStats(state, weekStart, iso(end));
      weeklySummary.innerHTML = `
        <b>Selected:</b> Week of <span class="mono">${weekStart}</span> •
        Completion: <span class="mono">${Math.round(stats.rate*100)}%</span> (${stats.done}/${stats.total})
      `;
    }
    updateBadges(state);
    window.LCT.setState(state); // persist any structure changes
  }


  function monthKey(d){
    const y=d.getFullYear();
    const m=String(d.getMonth()+1).padStart(2,"0");
    return `${y}-${m}`;
  }
  function quarterKey(d){
    const y=d.getFullYear();
    const q = Math.floor(d.getMonth()/3)+1;
    return `${y}-Q${q}`;
  }
  function startOfMonth(d){ const x=new Date(d.getFullYear(), d.getMonth(), 1); x.setHours(0,0,0,0); return x; }
  function endOfMonth(d){ const x=new Date(d.getFullYear(), d.getMonth()+1, 0); x.setHours(0,0,0,0); return x; }
  function startOfQuarter(d){ const q=Math.floor(d.getMonth()/3); const x=new Date(d.getFullYear(), q*3, 1); x.setHours(0,0,0,0); return x; }
  function endOfQuarter(d){ const s=startOfQuarter(d); const x=new Date(s.getFullYear(), s.getMonth()+3, 0); x.setHours(0,0,0,0); return x; }

  function openMonthlyFlow(){
    const state = ensureReviews(window.LCT.getState());
    state.reviews.monthly = state.reviews.monthly || {};
    const now = new Date(); now.setHours(0,0,0,0);
    const k = monthKey(now);
    const start = startOfMonth(now);
    const end = endOfMonth(now);
    const stats = computeWindowStats(state, iso(start), iso(end));

    $("monthlyTitle").textContent = `Monthly Review — ${k}`;
    $("monthlySub").textContent = `Coverage: ${iso(start)} → ${iso(end)}.`;
    $("monthlyKpis").innerHTML = `
      <div class="box"><b>${Math.round(stats.rate*100)}%</b><span>Month completion (${stats.done}/${stats.total})</span></div>
      <div class="box"><b>${state.goals.length}</b><span>Goals</span></div>
      <div class="box"><b>${state.habits.length}</b><span>Habits</span></div>
    `;

    const existing = state.reviews.monthly[k] || {};
    $("monthlyReality").value = existing.reality ?? "";
    $("monthlySystems").value = existing.systems ?? "";
    $("monthlyLevers").value = existing.levers ?? "";
    $("monthlyCommit").value = existing.commit ?? "";

    $("btnSaveMonthly").onclick = ()=>{
      state.reviews.monthly[k] = {
        reality: $("monthlyReality").value.trim(),
        systems: $("monthlySystems").value.trim(),
        levers: $("monthlyLevers").value.trim(),
        commit: $("monthlyCommit").value.trim(),
        updatedAt: new Date().toISOString()
      };
      window.LCT.setState(state);
      modalMonthlyReview.close();
      renderCoachTab();
      updateBadges(state);
      alert("Monthly review saved.");
    };

    $("btnCopyMonthly").onclick = ()=>{
      const packet = markdownPacket(state);
      setClipboard(packet);
      alert("Copied a reflection packet to clipboard.");
    };

    modalMonthlyReview.showModal();
  }

  function openQuarterlyFlow(){
    const state = ensureReviews(window.LCT.getState());
    state.reviews.quarterly = state.reviews.quarterly || {};
    const now = new Date(); now.setHours(0,0,0,0);
    const k = quarterKey(now);
    const start = startOfQuarter(now);
    const end = endOfQuarter(now);
    const stats = computeWindowStats(state, iso(start), iso(end));

    $("quarterlyTitle").textContent = `Quarterly Review — ${k}`;
    $("quarterlySub").textContent = `Coverage: ${iso(start)} → ${iso(end)}.`;
    $("quarterlyKpis").innerHTML = `
      <div class="box"><b>${Math.round(stats.rate*100)}%</b><span>Quarter completion (${stats.done}/${stats.total})</span></div>
      <div class="box"><b>${state.goals.length}</b><span>Goals</span></div>
      <div class="box"><b>${state.habits.length}</b><span>Habits</span></div>
    `;

    const existing = state.reviews.quarterly[k] || {};
    $("quarterlyOutcomes").value = existing.outcomes ?? "";
    $("quarterlyBottlenecks").value = existing.bottlenecks ?? "";
    $("quarterlyRedesign").value = existing.redesign ?? "";
    $("quarterlyIntent").value = existing.intent ?? "";

    $("btnSaveQuarterly").onclick = ()=>{
      state.reviews.quarterly[k] = {
        outcomes: $("quarterlyOutcomes").value.trim(),
        bottlenecks: $("quarterlyBottlenecks").value.trim(),
        redesign: $("quarterlyRedesign").value.trim(),
        intent: $("quarterlyIntent").value.trim(),
        updatedAt: new Date().toISOString()
      };
      window.LCT.setState(state);
      modalQuarterlyReview.close();
      renderCoachTab();
      updateBadges(state);
      alert("Quarterly review saved.");
    };

    $("btnCopyQuarterly").onclick = ()=>{
      const packet = markdownPacket(state);
      setClipboard(packet);
      alert("Copied a reflection packet to clipboard.");
    };

    modalQuarterlyReview.showModal();
  }


  function openWeeklyFlow(weekStartIso){
    const state = ensureReviews(window.LCT.getState());
    const start = parseISO(weekStartIso);
    const end = new Date(start); end.setDate(end.getDate()+6);
    const endIso = iso(end);
    const stats = computeWindowStats(state, weekStartIso, endIso);

    $("weeklyTitle").textContent = `Weekly Review — Week of ${weekStartIso}`;
    $("weeklySub").textContent = `Coverage: ${weekStartIso} → ${endIso}. Use the prompts to interpret your data and choose levers.`;

    $("weeklyKpis").innerHTML = `
      <div class="box"><b>${Math.round(stats.rate*100)}%</b><span>Completion (${stats.done}/${stats.total})</span></div>
      <div class="box"><b>${state.habits.length}</b><span>Active habits</span></div>
      <div class="box"><b>${state.settings?.mvd?.habitsToHit ?? 2}</b><span>Baseline day</span></div>
    `;

    const existing = state.reviews.weekly[weekStartIso] || {};
    $("weeklySleep").value = existing.sleep ?? "";
    $("weeklyStress").value = existing.stress ?? "";
    $("weeklyEnergy").value = existing.energy ?? "";
    $("weeklyComplexity").value = existing.complexity ?? "";
    $("weeklyReality").value = existing.reality ?? "";
    $("weeklyMeaning").value = existing.meaning ?? "";
    $("weeklyLevers").value = existing.levers ?? "";
    $("weeklyCommit").value = existing.commit ?? "";

    $("btnSaveWeekly").onclick = ()=>{
      state.reviews.weekly[weekStartIso] = {
        sleep: $("weeklySleep").value.trim(),
        stress: $("weeklyStress").value.trim(),
        energy: $("weeklyEnergy").value.trim(),
        complexity: $("weeklyComplexity").value.trim(),
        reality: $("weeklyReality").value.trim(),
        meaning: $("weeklyMeaning").value.trim(),
        levers: $("weeklyLevers").value.trim(),
        commit: $("weeklyCommit").value.trim(),
        updatedAt: new Date().toISOString()
      };
      window.LCT.setState(state);
      modalWeeklyReview.close();
      renderReviewTab();
      renderCoachTab();
      alert("Weekly review saved.");
    };

    $("btnCopyWeekly").onclick = ()=>{
      // export just this week + packet summary
      const packet = markdownPacket(state);
      setClipboard(packet);
      alert("Copied a reflection packet to clipboard.");
    };

    modalWeeklyReview.showModal();
  }

  
  function renderCoachTab(){
    const state = ensureReviews(window.LCT.getState());
    const scores = scoreCoach(state);
    $("coachScores").innerHTML = `
      <div class="box"><b>${scores.APS}/10</b><span>APS (adherence proxy)</span></div>
      <div class="box"><b>${scores.RSS}/10</b><span>RSS (recovery strain proxy)</span></div>
      <div class="box"><b>${scores.CB}/5</b><span>Complexity budget</span></div>
    `;

    const guidance = coachGuidanceFromScores(scores);
    const top = buildTopActions(state, scores);
    const topEl = $("coachTopActions");
    if(topEl){
      topEl.innerHTML="";
      for(const a of top){
        const div=document.createElement("div");
        div.className="item";
        div.innerHTML = `<div><h3>${a.title}</h3><div class="meta">${a.body}</div></div><div class="right"><span class="tag">next</span></div>`;
        topEl.appendChild(div);
      }
    }

    const planTxt = buildCoachPlan(state, scores);
    const planEl = $("coachPlan");
    if(planEl){ planEl.innerHTML = "<pre style=\"white-space:pre-wrap;margin:0\">"+planTxt.replace(/</g,"&lt;")+"</pre>"; }
    updateBadges(state);
    const list = $("coachGuidance");
    list.innerHTML = "";
    for(const g of guidance){
      const div=document.createElement("div");
      div.className="item";
      div.innerHTML = `<div><h3>${g.title}</h3><div class="meta">${g.body}</div></div><div class="right">
          <span class="tag ${t.listId==="work"?"tag-work":t.listId==="personal"?"tag-personal":"tag-neutral"}">${(listById(state,t.listId)?.name||"")}</span><span class="tag">${g.tag}</span></div>`;
      list.appendChild(div);
    }

    updateBadges(state);
    updateBadges(state);
    window.LCT.setState(state);
  }

  function openGPTPacket(){
    const state = ensureReviews(window.LCT.getState());
    const packet = markdownPacket(state);
    $("gptPacketText").value = packet;
    $("btnCopyGPTPacket2").onclick = ()=>{ setClipboard(packet); alert("Copied."); };
    $("btnDownloadGPTPacket").onclick = ()=>{
      const blob = new Blob([packet], {type:"text/markdown"});
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `life-compass-reflection-${iso(new Date())}.md`;
      a.click();
      URL.revokeObjectURL(a.href);
    };
    modalGPTPacket.showModal();
  }

  // Wire review buttons
  $("btnOpenWeekly")?.addEventListener("click", ()=>{
    const state = ensureReviews(window.LCT.getState());
    const weeks = getWeekOptions(state, 52);
    const k = reviewWeek.value || weeks[0];
    if(k) openWeeklyFlow(k);
  });
  $("btnOpenMonthly")?.addEventListener("click", openMonthlyFlow);
  $("btnOpenQuarterly")?.addEventListener("click", openQuarterlyFlow);
  $("btnExportGPTPacket")?.addEventListener("click", openGPTPacket);

  // Coach buttons
  $("btnRefreshCoach")?.addEventListener("click", renderCoachTab);
  $("btnCopyCoach")?.addEventListener("click", ()=>{
    const state = ensureReviews(window.LCT.getState());
    const scores = scoreCoach(state);
    const guidance = coachGuidanceFromScores(scores);
    const top = buildTopActions(state, scores);
    const topEl = $("coachTopActions");
    if(topEl){
      topEl.innerHTML="";
      for(const a of top){
        const div=document.createElement("div");
        div.className="item";
        div.innerHTML = `<div><h3>${a.title}</h3><div class="meta">${a.body}</div></div><div class="right"><span class="tag">next</span></div>`;
        topEl.appendChild(div);
      }
    }

    const planTxt = buildCoachPlan(state, scores);
    const planEl = $("coachPlan");
    if(planEl){ planEl.innerHTML = "<pre style=\"white-space:pre-wrap;margin:0\">"+planTxt.replace(/</g,"&lt;")+"</pre>"; }
    updateBadges(state);
    const txt = [
      "Life Compass — Coach Summary",
      `APS: ${scores.APS}/10 • RSS: ${scores.RSS}/10 • CB: ${scores.CB}/5`,
      `28-day completion: ${Math.round(scores.stats28.rate*100)}% (${scores.stats28.done}/${scores.stats28.total})`,
      "",
      ...guidance.map(g=>`- ${g.title}: ${g.body}`)
    ].join("\n");
    setClipboard(txt);
    alert("Coach summary copied.");
  });


  
  function ensureAlchemy(state){
    state.alchemy = state.alchemy || {};
    return state;
  }
  
  function ensureSystems(state){
    state.systems = state.systems || { daily:{}, experiments:{} };
    state.systems.daily = state.systems.daily || {};
    state.systems.experiments = state.systems.experiments || {};
    return state;
  }

function ensureBaseline(state){
    state.settings = state.settings || {};
    state.settings.mvd = state.settings.mvd || { habitsToHit: 4, pillars: [] };
    if(!Array.isArray(state.settings.mvd.pillars)) state.settings.mvd.pillars = [];
    return state;
  }

// -------------------- To-Do (Tasks) --------------------
  function ensureTodos(state){
    state.todos = state.todos || { lists: [], tasks: [] , myDay: {} };
    if(!Array.isArray(state.todos.lists) || state.todos.lists.length===0){
      state.todos.lists = [
        {id:"work", name:"Work"},
        {id:"personal", name:"Personal"},
        {id:"admin", name:"Admin"}
      ];
    }
    state.todos.tasks = Array.isArray(state.todos.tasks) ? state.todos.tasks : [];
    state.todos.myDay = state.todos.myDay || {};
    return state;
  }

  const todoQuick = $("todoQuick");
  const todoListSelect = $("todoListSelect");
  const todoLists = $("todoLists");
  const todoList = $("todoList");
  const todoFilter = $("todoFilter");
  const todoSort = $("todoSort");
  const todoHeaderPill = $("todoHeaderPill");
  const todoListEl = $("todoList");

  const modalTodoTask = $("modalTodoTask");
  const todoTaskTitle = $("todoTaskTitle");
  const todoTaskSub = $("todoTaskSub");
  const todoTitle = $("todoTitle");
  const todoDue = $("todoDue");
  const todoPriority = $("todoPriority");
  const todoNotes = $("todoNotes");
  const todoRecurring = $("todoRecurring");
  const todoRecFreq = $("todoRecFreq");
  const btnTodoSave = $("btnTodoSave");
  const btnTodoDelete = $("btnTodoDelete");
  const btnTodoToggleMyDay = $("btnTodoToggleMyDay");
  const todoStepsEl = $("todoSteps");
  const todoStepQuick = $("todoStepQuick");
  const btnTodoAddStep = $("btnTodoAddStep");

  const btnTodoNew = $("btnTodoNew");
  const btnTodoNewList = $("btnTodoNewList");
  const btnTodoMyDay = $("btnTodoMyDay");

  let todoMode = "list"; // 'list' or 'myday'
  let editingTaskId = null;
  let workingSteps = [];

  function uid(){ return Math.random().toString(16).slice(2) + "-" + Date.now().toString(16); }
  function todayIso(){
    const d=new Date(); d.setHours(0,0,0,0); return iso(d);
  }
  function listById(state, id){ return state.todos.lists.find(l=>l.id===id); }
  function taskById(state, id){ return state.todos.tasks.find(t=>t.id===id); }

  function fillTodoListSelect(state){
    if(!todoListSelect) return;
    const prev = todoListSelect.value || "personal";
    todoListSelect.innerHTML = "";
    for(const l of state.todos.lists){
      const o=document.createElement("option");
      o.value=l.id; o.textContent=l.name;
      todoListSelect.appendChild(o);
    }
    todoListSelect.value = state.todos.lists.some(l=>l.id===prev) ? prev : "personal";
    // modal select
    if(todoList){
      const prev2 = todoList.value || prev;
      todoList.innerHTML = "";
      for(const l of state.todos.lists){
        const o=document.createElement("option");
        o.value=l.id; o.textContent=l.name;
        todoList.appendChild(o);
      }
      todoList.value = state.todos.lists.some(l=>l.id===prev2) ? prev2 : "personal";
    }
  }

  function renderTodoLists(){
    const state = ensureTodos(window.LCT.getState());
    fillTodoListSelect(state);
    if(!todoLists) return;
    todoLists.innerHTML = "";

    // My Day pseudo-list
    const myDayItem = document.createElement("div");
    myDayItem.className = "item";
    myDayItem.innerHTML = `<div><h3>My Day</h3><div class="meta">Focus list for today</div></div><div class="right">
          <span class="tag ${t.listId==="work"?"tag-work":t.listId==="personal"?"tag-personal":"tag-neutral"}">${(listById(state,t.listId)?.name||"")}</span><span class="tag">today</span></div>`;
    myDayItem.addEventListener("click", ()=>{ todoMode="myday"; renderTodo(); });
    todoLists.appendChild(myDayItem);

    for(const l of state.todos.lists){
      const openCount = state.todos.tasks.filter(t=>t.listId===l.id && !t.done).length;
      const el=document.createElement("div");
      el.className="item";
      el.innerHTML = `<div><h3>${l.name}</h3><div class="meta">${openCount} open task(s)</div></div><div class="right">
          <span class="tag ${t.listId==="work"?"tag-work":t.listId==="personal"?"tag-personal":"tag-neutral"}">${(listById(state,t.listId)?.name||"")}</span><span class="tag ${l.id==="work"?"tag-work":l.id==="personal"?"tag-personal":"tag-neutral"}">${l.name}</span></div>`;
      el.addEventListener("click", ()=>{ todoMode="list"; todoListSelect.value=l.id; renderTodo(); });
      todoLists.appendChild(el);
    }
    updateBadges(state);
    window.LCT.setState(state);
  }

  function taskMatchesFilter(t){
    const f = todoFilter?.value || "all";
    if(f==="all") return true;
    if(f==="open") return !t.done;
    if(f==="done") return !!t.done;
    const today = todayIso();
    if(f==="today") return !t.done && t.due===today;
    if(f==="overdue") return !t.done && t.due && t.due < today;
    return true;
  }

  function sortTasks(a,b){
    const s = todoSort?.value || "due";
    if(s==="created") return (b.createdAt||"").localeCompare(a.createdAt||"");
    if(s==="priority") return (b.priority||0) - (a.priority||0) || (a.due||"9999").localeCompare(b.due||"9999");
    // due
    return (a.due||"9999-99-99").localeCompare(b.due||"9999-99-99") || (b.priority||0)-(a.priority||0);
  }

  function renderTodo(){
    const state = ensureTodos(window.LCT.getState());
    fillTodoListSelect(state);
    renderTodoLists();

    if(!todoListEl) return;
    const listId = todoListSelect?.value || "personal";
    const listName = todoMode==="myday" ? "My Day" : (listById(state, listId)?.name || "Tasks");
    if(todoHeaderPill) todoHeaderPill.textContent = listName;

    let tasks = state.todos.tasks.slice();
    if(todoMode==="myday"){
      const day = todayIso();
      const set = state.todos.myDay?.[day] || {};
      tasks = tasks.filter(t=> set[t.id]);
    } else {
      tasks = tasks.filter(t=> t.listId===listId);
    }
    tasks = tasks.filter(taskMatchesFilter).sort(sortTasks);

    todoListEl.innerHTML = "";
    if(tasks.length===0){
      const n=document.createElement("div");
      n.className="notice";
      n.textContent = (todoMode==="myday") ? "No tasks in My Day yet. Add tasks, then tap “Add to My Day”." : "No tasks yet. Add one above.";
      todoListEl.appendChild(n);
      window.LCT.setState(state);
      return;
    }

    const today = todayIso();
    for(const t of tasks){
      const dueLabel = t.due ? (t.due===today ? "Due today" : (t.due < today ? "Overdue" : `Due ${t.due}`)) : "No due date";
      const p = Number(t.priority||0);
      const pTag = p===3 ? "High" : p===2 ? "Med" : p===1 ? "Low" : "—";

      const item = document.createElement("div");
      item.className="item";
      item.innerHTML = `
        <div style="flex:1;min-width:0">
          <h3>${t.title}</h3>
          <div class="meta">${dueLabel} • Priority: ${pTag} • Steps: ${t.steps?`${(t.steps||[]).filter(s=>s.done).length}/${(t.steps||[]).length}`:"0/0"}</div>
          ${t.notes?`<div class="tiny">${t.notes.replace(/</g,"&lt;").slice(0,120)}${t.notes.length>120?"…":""}</div>`:""}
        </div>
        <div class="right">
          <span class="tag ${t.listId==="work"?"tag-work":t.listId==="personal"?"tag-personal":"tag-neutral"}">${(listById(state,t.listId)?.name||"")}</span>
          <label class="pill" style="display:flex;gap:8px;align-items:center;cursor:pointer">
            <input type="checkbox" ${t.done?"checked":""} data-task="${t.id}"/>
            Done
          </label>
          <button class="btn ghost" data-edit="${t.id}">Edit</button>
        </div>
      `;
      item.addEventListener("click", (e)=>{ if(e.target.tagName!=="INPUT" && e.target.tagName!=="BUTTON"){ openTaskModal(t.id); } });
      todoListEl.appendChild(item);
    }

    // bind toggles
    todoListEl.querySelectorAll("input[type=checkbox][data-task]").forEach(cb=>{
      cb.addEventListener("change",(e)=>{
        const id=e.target.dataset.task;
        const task = taskById(state,id);
        if(task){
          const wasDone = !!task.done;
          task.done = !!e.target.checked;
          task.updatedAt = new Date().toISOString();
          if(!wasDone && task.done && task.recurring && task.recurrence?.freq){
            // Spawn next occurrence
            const freq = task.recurrence.freq;
            let due = task.due ? parseISO(task.due) : new Date();
            if(freq==="daily") due.setDate(due.getDate()+1);
            else if(freq==="weekly") due.setDate(due.getDate()+7);
            else if(freq==="monthly") due = new Date(due.getFullYear(), due.getMonth()+1, due.getDate());
            const next = {
              ...task,
              steps: (task.steps||[]).map(s=>({ ...s, id: uid(), done:false })),
              id: uid(),
              done: false,
              due: iso(due),
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            };
            state.todos.tasks.unshift(next);
          }
        }
        window.LCT.setState(state);
        renderTodo();
      });
    });
    todoListEl.querySelectorAll("button[data-edit]").forEach(b=>{
      b.addEventListener("click", ()=> openTaskModal(b.dataset.edit));
    });

    updateBadges(state);
    window.LCT.setState(state);
  }

  function openTaskModal(taskId=null){
    const state = ensureTodos(window.LCT.getState());
    fillTodoListSelect(state);
    editingTaskId = taskId;
    const editing = !!taskId;
    const t = editing ? taskById(state, taskId) : null;

    todoTaskTitle.textContent = editing ? "Edit task" : "New task";
    todoTaskSub.textContent = editing ? "Update details, due date, and priority." : "Create a one-off task.";
    btnTodoDelete.style.display = editing ? "inline-flex" : "none";

    todoTitle.value = t?.title || "";
    todoNotes.value = t?.notes || "";
    todoDue.value = t?.due || "";
    todoPriority.value = String(t?.priority || 0);
    todoList.value = t?.listId || (todoListSelect?.value || "personal");
    if(todoRecurring){
      todoRecurring.checked = !!t?.recurring;
    }
    if(todoRecFreq){
      todoRecFreq.value = t?.recurrence?.freq || "weekly";
      todoRecFreq.style.display = (todoRecurring && todoRecurring.checked) ? "" : "none";
    }
    if(todoRecurring){
      todoRecurring.onchange = ()=>{ if(todoRecFreq) todoRecFreq.style.display = todoRecurring.checked ? "" : "none"; };
    }

    const day = todayIso();
    const set = state.todos.myDay?.[day] || {};
    const inMyDay = t ? !!set[t.id] : false;
    btnTodoToggleMyDay.textContent = inMyDay ? "Remove from My Day" : "Add to My Day";

    btnTodoToggleMyDay.onclick = ()=>{
      const state2 = ensureTodos(window.LCT.getState());
      const day2 = todayIso();
      state2.todos.myDay[day2] = state2.todos.myDay[day2] || {};
      const set2 = state2.todos.myDay[day2];
      if(editingTaskId){
        if(set2[editingTaskId]) delete set2[editingTaskId];
        else set2[editingTaskId] = true;
        window.LCT.setState(state2);
        openTaskModal(editingTaskId); // refresh view
        renderTodo();
      } else {
        alert("Save the task first, then add it to My Day.");
      }
    };

    btnTodoSave.onclick = ()=>{
      const title = (todoTitle.value||"").trim();
      if(!title){ alert("Please enter a task title."); return; }
      const payload = {
        id: editing ? t.id : uid(),
        title,
        notes: (todoNotes.value||"").trim(),
        due: (todoDue.value||"") || "",
        priority: Number(todoPriority.value||0),
        listId: todoList.value || "personal",
        recurring: !!(todoRecurring && todoRecurring.checked),
        recurrence: (todoRecurring && todoRecurring.checked) ? { freq: (todoRecFreq?.value||"weekly") } : null,
        steps: Array.isArray(workingSteps) ? workingSteps.slice(0,25) : [],
        done: editing ? !!t.done : false,
        createdAt: editing ? t.createdAt : new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      if(editing){
        const idx = state.todos.tasks.findIndex(x=>x.id===t.id);
        state.todos.tasks[idx] = payload;
      } else {
        state.todos.tasks.unshift(payload);
      }
      window.LCT.setState(state);
      modalTodoTask.close();
      renderTodo();
    };

    btnTodoDelete.onclick = ()=>{
      if(!editing) return;
      if(!confirm("Delete this task?")) return;
      state.todos.tasks = state.todos.tasks.filter(x=>x.id!==t.id);
      // remove from myDay sets
      for(const dayK of Object.keys(state.todos.myDay||{})){
        if(state.todos.myDay[dayK]?.[t.id]) delete state.todos.myDay[dayK][t.id];
      }
      window.LCT.setState(state);
      modalTodoTask.close();
      renderTodo();
    };

    modalTodoTask.showModal();
  }

  // Quick add
  if(todoQuick){
    todoQuick.addEventListener("keydown",(e)=>{
      if(e.key==="Enter"){
        e.preventDefault();
        const state = ensureTodos(window.LCT.getState());
        const title = (todoQuick.value||"").trim();
        if(!title) return;
        const listId = todoListSelect?.value || "personal";
        state.todos.tasks.unshift({
          id: uid(),
          title,
          notes:"",
          due:"",
          priority:0,
          listId,
          done:false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          steps: []
        });
        todoQuick.value="";
        window.LCT.setState(state);
        renderTodo();
      }
    });
  }

  btnTodoNew?.addEventListener("click", ()=> openTaskModal());
  btnTodoMyDay?.addEventListener("click", ()=>{ todoMode="myday"; renderTodo(); });
  todoListSelect?.addEventListener("change", ()=>{ todoMode="list"; renderTodo(); });
  todoFilter?.addEventListener("change", renderTodo);
  todoSort?.addEventListener("change", renderTodo);

  btnTodoNewList?.addEventListener("click", ()=>{
    const state = ensureTodos(window.LCT.getState());
    const name = prompt("New list name (e.g., Work, Admin):");
    if(!name) return;
    const id = name.toLowerCase().replace(/[^a-z0-9]+/g,"-").slice(0,18) || uid().slice(0,6);
    if(state.todos.lists.some(l=>l.id===id)){
      alert("That list id already exists. Try a different name.");
      return;
    }
    state.todos.lists.push({id, name: name.trim()});
    window.LCT.setState(state);
    fillTodoListSelect(state);
    todoListSelect.value = id;
    todoMode="list";
    renderTodo();
  });

  // -------------------- Mobile nav + More modal --------------------
  const modalMore = $("modalMore");
  function activateTab(tab){
    // Update top tabs
    document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active", x.dataset.tab===tab));
    // Show section
    document.querySelectorAll(".section").forEach(s=>s.classList.toggle("active", s.id===tab));
    // Update mobile nav state
    document.querySelectorAll(".mobile-nav .mnav-btn").forEach(b=>{
      const t = b.dataset.tab;
      b.classList.toggle("active", (t===tab) || (t==="dashboard" && tab==="dashboard"));
    });
    // render specialized tabs
    if(tab==="review") renderReviewTab();
    if(tab==="coach") renderCoachTab();
    if(tab==="todo") renderTodo();
    if(tab==="dashboard") renderHomeOS();
    if(tab==="settings") renderBaselineEditor();
    if(tab==="systems") renderSystemsTab();
      if(tab==="systems") renderSystemsTab();
  }

  // Hook mobile nav buttons
  document.querySelectorAll(".mobile-nav .mnav-btn").forEach(b=>{
    b.addEventListener("click", ()=>{
      const t=b.dataset.tab;
      if(t==="more"){ activateTab("more"); return; }
      activateTab(t);
      window.scrollTo({top:0, behavior:"smooth"});
    });
  });

  // Hook More modal buttons
  document.querySelectorAll("#moreList button[data-goto]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const t = btn.dataset.goto;
      modalMore.close();
      activateTab(t);
      window.scrollTo({top:0, behavior:"smooth"});
    });
  });

  // Ensure todo renders when user clicks desktop tab too
  document.querySelectorAll(".tab").forEach(t=>{
    t.addEventListener("click", ()=>{
      if(t.dataset.tab==="todo") renderTodo();
    });
  });

  // Initialize To-Do structures and render once
  (function initTodos(){
    const state = ensureTodos(window.LCT.getState());
    updateBadges(state);
    window.LCT.setState(state);
    renderTodoLists();
  })();




  // -------------------- Systems Tab --------------------

  const ENV_PRESETS = {
    home: {
      friction: "Common home friction:\n- Snacks/temptations visible\n- Couch/TV autopilot\n- Devices/notifications\n- No clear ‘start’ cue for your habit",
      change: "Default home change:\n- Put the next action in sight (water, shoes, journal)\n- Remove/relocate trigger items (snacks, apps)\n- Create a 2-minute ‘start cue’ (timer + playlist)\n- Set a single ‘no screens’ block (first/last 30 min)"
    },
    work: {
      friction: "Common work friction:\n- Meetings fragment time\n- Context switching\n- Stress/urgency bias\n- Food defaults are random",
      change: "Default work change:\n- Add 2 anchors: start-of-day + lunch/afternoon reset\n- Use 25–50 min focus block + DND\n- Pre-decide 1 default lunch/snack\n- Put your habit in the calendar (10–20 min)"
    },
    travel: {
      friction: "Common travel friction:\n- No routine cues\n- Limited equipment/access\n- Social schedule changes\n- Sleep disruption",
      change: "Default travel change:\n- Define a travel baseline (2–3 habits)\n- Pack a ‘go kit’ (bands, protein, electrolytes)\n- Choose a 10–15 min bodyweight template\n- Protect sleep window (earlier wind-down)"
    }
  };

  function recommendTodaysLever(state){
    const scores = scoreCoach(state);
    const dIso = todayIso();
    const sys = state.systems?.daily?.[dIso] || {};

    // Priority rules (simple + interpretable)
    // 1) High recovery strain or low energy => Energy
    const energyLow = (sys.energy && Number(sys.energy) <= 2) || (sys.sleep && Number(sys.sleep) <= 2);
    if(scores.RSS >= 7 || energyLow){
      return { lever:"Energy", why:"Recovery strain is high or energy is low. Stabilize sleep/recovery and reduce load to protect consistency." };
    }

    // 2) Low adherence or high complexity => Structure
    if(scores.APS <= 4 || scores.CB >= 4){
      return { lever:"Structure", why:"Adherence is slipping or complexity is too high. Simplify, use anchors, and protect your baseline day." };
    }

    // 3) Overwhelm likely (OOR/UFR) or many habits => Environment
    if(scores.OOR >= 5 || scores.UFR >= 5 || scores.activeHabits >= 12){
      return { lever:"Environment", why:"Overwhelm/friction is likely. Reduce triggers and make the next action obvious and easy." };
    }

    // 4) If meaning fields empty in Systems => Meaning
    const meaningMissing = !(sys.emotion && sys.aligned);
    if(meaningMissing){
      return { lever:"Meaning", why:"Meaning fields are empty today. Name the emotion and choose one aligned action (small but real)." };
    }

    return { lever:"Environment", why:"Default recommendation: adjust the environment to lower friction and raise follow-through." };
  }

    const SYSTEM_LIBRARY = [
    {id:"env-1", lever:"Environment", title:"Prep the path", body:"Put the next action in your line of sight (shoes by door, water on desk)."},
    {id:"env-2", lever:"Environment", title:"Remove the trigger", body:"Delete/disable the cue that leads to the behavior you’re trying to reduce (apps, snacks, notifications)."},
    {id:"energy-1", lever:"Energy", title:"Earlier sleep window", body:"Move bedtime 30–60 minutes earlier for 7 days; keep wake time consistent."},
    {id:"energy-2", lever:"Energy", title:"Protein + fiber default", body:"Pick one default meal that hits protein + fiber and repeat it on weekdays."},
    {id:"struct-1", lever:"Structure", title:"Two anchors", body:"Lock in 2 daily anchors (morning + evening). Everything else is optional."},
    {id:"struct-2", lever:"Structure", title:"Reduce complexity", body:"Pause 2–4 habits for a week. Stability before expansion."},
    {id:"meaning-1", lever:"Meaning", title:"Identity cue", body:"Write one sentence: “I’m the kind of person who ___.” Then do the smallest proof."},
    {id:"meaning-2", lever:"Meaning", title:"Name the feeling", body:"Label the dominant emotion; choose the smallest aligned action anyway."},
  ];

  let systemsMode = "Environment";

  function sysKeyDay(dIso){ return dIso; }
  function sysKeyWeek(d){
    const s = startOfWeek(d);
    return iso(s);
  }

  function systemsKpis(state){
    // Lightweight: show adherence trend + baseline + last weekly experiment
    const scores = scoreCoach(state);
    const wk = iso(startOfWeek(new Date()));
    const exp = state.systems.experiments?.[wk];
    return { scores, exp, wk };
  }

  function renderSystemsLibrary(){
    const el = $("systemsLibrary");
    if(!el) return;
    el.innerHTML = "";
    for(const item of SYSTEM_LIBRARY){
      const div=document.createElement("div");
      div.className="item";
      div.innerHTML = `<div><h3>${item.lever}: ${item.title}</h3><div class="meta">${item.body}</div></div><div class="right"><button class="btn" data-apply="${item.id}">Use</button></div>`;
      el.appendChild(div);
    }
    el.querySelectorAll("button[data-apply]").forEach(b=>{
      b.addEventListener("click", ()=>{
        const id=b.dataset.apply;
        const it = SYSTEM_LIBRARY.find(x=>x.id===id);
        if(!it) return;
        // insert into weekly experiment
        const st = ensureSystems(window.LCT.getState());
        const wk = iso(startOfWeek(new Date()));
        st.systems.experiments[wk] = st.systems.experiments[wk] || { hypothesis:"", intervention:"", metric:"", friction:"", notes:"", updatedAt:"" };
        const ex = st.systems.experiments[wk];
        ex.intervention = (ex.intervention ? ex.intervention + "\n" : "") + `- ${it.lever}: ${it.title} — ${it.body}`;
        ex.updatedAt = new Date().toISOString();
        window.LCT.setState(st);
        renderSystemsTab();
        alert("Added to weekly experiment.");
      });
    });
  }

  function panelEnvironment(state, dIso){
    const entry = state.systems.daily[dIso] || {};
    return `
      <h3>Environment (friction + design)</h3>
      <div class="sub">What in your environment made the desired behavior easier/harder today?</div>
      <div class="hr"></div>
      <div class="row" style="gap:10px;flex-wrap:wrap">
        <div class="pill">Environment presets</div>
        <button class="btn" id="btnPresetHome" type="button">Home</button>
        <button class="btn" id="btnPresetWork" type="button">Work</button>
        <button class="btn" id="btnPresetTravel" type="button">Travel</button>
      </div>
      <div class="help">Tap a preset to auto-fill common friction + a default change. Edit to match your reality.</div>
      <label class="tiny" style="margin-top:10px">Friction audit (what blocked you?)</label>
      <textarea id="sysEnvFriction" class="input" placeholder="Cues, triggers, locations, timing, devices, food environment…">${(entry.envFriction||"").replace(/</g,"&lt;")}</textarea>
      <label class="tiny" style="margin-top:10px">1 change you’ll make (reduce friction / add cue)</label>
      <textarea id="sysEnvChange" class="input" placeholder="Example: pack gym bag at night; remove snacks; set Do Not Disturb…">${(entry.envChange||"").replace(/</g,"&lt;")}</textarea>
    `;
  }

  function panelEnergy(state, dIso){
    const entry = state.systems.daily[dIso] || {};
    const sleep = entry.sleep ?? 3;
    const stress = entry.stress ?? 3;
    const energy = entry.energy ?? 3;
    return `
      <h3>Energy (capacity + recovery)</h3>
      <div class="sub">Track strain and choose the right day type: baseline / recovery / push.</div>
      <div class="hr"></div>
      <div class="formgrid">
        <div>
          <label class="tiny">Sleep quality (1–5)</label>
          <input id="sysSleep" class="input" type="range" min="1" max="5" value="${sleep}">
          <div class="help">Current: <span class="mono" id="sysSleepVal">${sleep}</span></div>
        </div>
        <div>
          <label class="tiny">Stress (1–5)</label>
          <input id="sysStress" class="input" type="range" min="1" max="5" value="${stress}">
          <div class="help">Current: <span class="mono" id="sysStressVal">${stress}</span></div>
        </div>
        <div>
          <label class="tiny">Energy (1–5)</label>
          <input id="sysEnergy" class="input" type="range" min="1" max="5" value="${energy}">
          <div class="help">Current: <span class="mono" id="sysEnergyVal">${energy}</span></div>
        </div>
      </div>
      <div class="hr"></div>
      <label class="tiny">Energy prescription</label>
      <textarea id="sysEnergyPlan" class="input" placeholder="If energy low: reduce load, simplify; if high: add 1 stretch.">${(entry.energyPlan||"").replace(/</g,"&lt;")}</textarea>
    `;
  }

  function panelStructure(state, dIso){
    const entry = state.systems.daily[dIso] || {};
    return `
      <h3>Structure (anchors + cadence)</h3>
      <div class="sub">Stability comes from anchors. Make your baseline day easy to hit.</div>
      <div class="hr"></div>
      <label class="tiny">Today’s anchors</label>
      <textarea id="sysAnchors" class="input" placeholder="Morning anchor / mid-day / evening…">${(entry.anchors||"").replace(/</g,"&lt;")}</textarea>
      <label class="tiny" style="margin-top:10px">What will you simplify tomorrow?</label>
      <textarea id="sysSimplify" class="input" placeholder="Remove steps, reduce habits, create defaults…">${(entry.simplify||"").replace(/</g,"&lt;")}</textarea>
    `;
  }

  function panelMeaning(state, dIso){
    const entry = state.systems.daily[dIso] || {};
    return `
      <h3>Meaning (inner life + alchemy)</h3>
      <div class="sub">Transform circumstances by choosing aligned action — especially under emotion.</div>
      <div class="hr"></div>
      <label class="tiny">Dominant emotion</label>
      <input id="sysEmotion" class="input" placeholder="e.g., anxious, energized, numb…" value="${(entry.emotion||"").replace(/</g,"&lt;")}">
      <label class="tiny" style="margin-top:10px">Interpretation (what is it asking for?)</label>
      <textarea id="sysInterpret" class="input" placeholder="What need is underneath?">${(entry.interpret||"").replace(/</g,"&lt;")}</textarea>
      <label class="tiny" style="margin-top:10px">Aligned action (small but real)</label>
      <textarea id="sysAligned" class="input" placeholder="What will you do anyway?">${(entry.aligned||"").replace(/</g,"&lt;")}</textarea>
      
    `;
  }

  function panelExperiment(state){
    const wk = iso(startOfWeek(new Date()));
    state.systems.experiments[wk] = state.systems.experiments[wk] || { hypothesis:"", intervention:"", metric:"", friction:"", notes:"", updatedAt:"" };
    const ex = state.systems.experiments[wk];
    return `
      <h3>Weekly Experiment</h3>
      <div class="sub">Run 1 small experiment per week. Change the system, not your willpower.</div>
      <div class="hr"></div>
      <label class="tiny">Hypothesis</label>
      <textarea id="sysHypothesis" class="input" placeholder="If I change X, then Y will improve because…">${(ex.hypothesis||"").replace(/</g,"&lt;")}</textarea>
      <label class="tiny" style="margin-top:10px">Intervention (what will you change?)</label>
      <textarea id="sysIntervention" class="input" placeholder="What you will do differently this week.">${(ex.intervention||"").replace(/</g,"&lt;")}</textarea>
      <label class="tiny" style="margin-top:10px">Metric (how will you know it worked?)</label>
      <textarea id="sysMetric" class="input" placeholder="Examples: baseline hits/week, workouts, step count, sleep quality…">${(ex.metric||"").replace(/</g,"&lt;")}</textarea>
      <label class="tiny" style="margin-top:10px">Expected friction (what could block it?)</label>
      <textarea id="sysFriction" class="input" placeholder="Time, travel, stress, access…">${(ex.friction||"").replace(/</g,"&lt;")}</textarea>
      <label class="tiny" style="margin-top:10px">Notes</label>
      <textarea id="sysNotes" class="input" placeholder="What you’ll watch or adjust mid-week.">${(ex.notes||"").replace(/</g,"&lt;")}</textarea>
      <div class="help">Week key: <span class="mono">${wk}</span></div>
    `;
  }

  function renderSystemsPanel(){
    const state = ensureSystems(ensureBaseline(ensureAlchemy(ensureReviews(window.LCT.getState()))));
    const dIso = todayIso();
    state.systems.daily[dIso] = state.systems.daily[dIso] || {};
    const panel = $("systemsPanel");
    if(!panel) return;
    if(systemsMode==="Environment") panel.innerHTML = panelEnvironment(state, dIso);
    else if(systemsMode==="Energy") panel.innerHTML = panelEnergy(state, dIso);
    else if(systemsMode==="Structure") panel.innerHTML = panelStructure(state, dIso);
    else if(systemsMode==="Meaning") panel.innerHTML = panelMeaning(state, dIso);
    else panel.innerHTML = panelExperiment(state);

    // environment presets
    const applyPreset = (key)=>{
      const p = ENV_PRESETS[key];
      if(!p) return;
      const f = $("sysEnvFriction");
      const c = $("sysEnvChange");
      if(f) f.value = p.friction;
      if(c) c.value = p.change;
    };
    $("btnPresetHome")?.addEventListener("click", ()=> applyPreset("home"));
    $("btnPresetWork")?.addEventListener("click", ()=> applyPreset("work"));
    $("btnPresetTravel")?.addEventListener("click", ()=> applyPreset("travel"));

    // bind range labels
    const bindRange = (id,valId)=>{
      const r=$(id), v=$(valId);
      if(r && v){ v.textContent = r.value; r.addEventListener("input", ()=> v.textContent = r.value); }
    };
    bindRange("sysSleep","sysSleepVal");
    bindRange("sysStress","sysStressVal");
    bindRange("sysEnergy","sysEnergyVal");

    window.LCT.setState(state);
  }

  function saveSystems(){
    const state = ensureSystems(ensureBaseline(ensureAlchemy(ensureReviews(window.LCT.getState()))));
    const dIso = todayIso();
    state.systems.daily[dIso] = state.systems.daily[dIso] || {};
    const e = state.systems.daily[dIso];

    // read fields if present
    const setIf = (k,id)=>{ const el=$(id); if(el) e[k]=el.value.trim(); };
    setIf("envFriction","sysEnvFriction");
    setIf("envChange","sysEnvChange");
    setIf("energyPlan","sysEnergyPlan");
    setIf("anchors","sysAnchors");
    setIf("simplify","sysSimplify");
    const emo=$("sysEmotion"); if(emo) e.emotion = emo.value.trim();
    setIf("interpret","sysInterpret");
    setIf("aligned","sysAligned");

    const sl=$("sysSleep"); if(sl) e.sleep = Number(sl.value);
    const st=$("sysStress"); if(st) e.stress = Number(st.value);
    const en=$("sysEnergy"); if(en) e.energy = Number(en.value);

    // weekly experiment
    const wk = iso(startOfWeek(new Date()));
    state.systems.experiments[wk] = state.systems.experiments[wk] || {};
    const ex = state.systems.experiments[wk];
    const setEx = (k,id)=>{ const el=$(id); if(el) ex[k]=el.value.trim(); };
    setEx("hypothesis","sysHypothesis");
    setEx("intervention","sysIntervention");
    setEx("metric","sysMetric");
    setEx("friction","sysFriction");
    setEx("notes","sysNotes");

    e.updatedAt = new Date().toISOString();
    ex.updatedAt = new Date().toISOString();

    window.LCT.setState(state);
    renderCoachTab();
    alert("Systems saved.");
  }

  function copySystems(){
    const state = ensureSystems(ensureBaseline(ensureAlchemy(ensureReviews(window.LCT.getState()))));
    const dIso = todayIso();
    const e = state.systems.daily?.[dIso] || {};
    const wk = iso(startOfWeek(new Date()));
    const ex = state.systems.experiments?.[wk] || {};
    const txt = [
      `SYSTEMS — ${dIso}`,
      "",
      "Environment:",
      `- Friction: ${e.envFriction||"—"}`,
      `- Change: ${e.envChange||"—"}`,
      "",
      "Energy:",
      `- Sleep: ${e.sleep??"—"}/5 • Stress: ${e.stress??"—"}/5 • Energy: ${e.energy??"—"}/5`,
      `- Plan: ${e.energyPlan||"—"}`,
      "",
      "Structure:",
      `- Anchors: ${e.anchors||"—"}`,
      `- Simplify: ${e.simplify||"—"}`,
      "",
      "Meaning:",
      `- Emotion: ${e.emotion||"—"}`,
      `- Interpretation: ${e.interpret||"—"}`,
      `- Aligned action: ${e.aligned||"—"}`,
      "",
      `WEEKLY EXPERIMENT (${wk}):`,
      `- Hypothesis: ${ex.hypothesis||"—"}`,
      `- Intervention: ${ex.intervention||"—"}`,
      `- Metric: ${ex.metric||"—"}`,
      `- Friction: ${ex.friction||"—"}`,
    ].join("\n");
    setClipboard(txt);
    alert("Copied.");
  }

  function renderSystemsTab(){
    const state = ensureSystems(ensureBaseline(ensureAlchemy(ensureReviews(window.LCT.getState()))));
    const { scores, exp, wk } = systemsKpis(state);
    const el = $("systemsKpis");
    if(el){
      el.innerHTML = `
        <div class="box"><b>${scores.APS}/10</b><span>Adherence</span></div>
        <div class="box"><b>${scores.RSS}/10</b><span>Recovery strain</span></div>
        <div class="box"><b>${state.settings.mvd.habitsToHit ?? 4}</b><span>Baseline day</span></div>
      `;
    }
    const lever = recommendTodaysLever(state);
    const leverEl = $("systemsLever");
    if(leverEl){
      leverEl.innerHTML = `<b>Today’s lever:</b> <span class="mono">${lever.lever}</span><br/><span class="sub">${lever.why}</span>`;
    }
    // Set default panel to the recommended lever unless user already chose something this session
    systemsMode = lever.lever;
    renderSystemsLibrary();
    renderSystemsPanel();

    // buttons
    $("btnSysEnv")?.addEventListener("click", ()=>{ systemsMode="Environment"; renderSystemsPanel(); });
    $("btnSysEnergy")?.addEventListener("click", ()=>{ systemsMode="Energy"; renderSystemsPanel(); });
    $("btnSysStruct")?.addEventListener("click", ()=>{ systemsMode="Structure"; renderSystemsPanel(); });
    $("btnSysMeaning")?.addEventListener("click", ()=>{ systemsMode="Meaning"; renderSystemsPanel(); });
    $("btnSysExperiment")?.addEventListener("click", ()=>{ systemsMode="Experiment"; renderSystemsPanel(); });

    { const b=$("btnSystemsSave"); if(b) b.onclick = saveSystems; }
    { const b=$("btnSystemsCopy"); if(b) b.onclick = copySystems; }

    window.LCT.setState(state);
  }


  // -------------------- Baseline Day + Daily Alchemy --------------------
  function renderBaselineEditor(){
    const state = ensureBaseline(ensureAlchemy(ensureReviews(window.LCT.getState())));
    const habitsToHit = state.settings.mvd.habitsToHit ?? 4;
    const pillarsSel = $("baselinePillars");
    const hitInput = $("baselineHabitsToHit");
    if(hitInput) hitInput.value = String(habitsToHit);

    if(pillarsSel){
      pillarsSel.innerHTML = "";
      for(const c of state.categories){
        const opt=document.createElement("option");
        opt.value = c.id;
        opt.textContent = c.name;
        if(state.settings.mvd.pillars.includes(c.id)) opt.selected = true;
        pillarsSel.appendChild(opt);
      }
    }

    $("btnSaveBaseline")?.addEventListener("click", ()=>{
      const st = ensureBaseline(window.LCT.getState());
      const n = Number(($("baselineHabitsToHit")?.value||"").trim());
      st.settings.mvd.habitsToHit = (!Number.isNaN(n) && n>0) ? Math.min(12, Math.max(1, n)) : 4;
      const sel = $("baselinePillars");
      if(sel){
        st.settings.mvd.pillars = Array.from(sel.selectedOptions).map(o=>o.value);
      }
      window.LCT.setState(st);
      renderCoachTab();
      updateBadges(st);
      alert("Baseline Day saved.");
    }, { once:true });

    window.LCT.setState(state);
  }

  
  
  function renderHomeOS(){
    const state = ensureBaseline(ensureReviews(window.LCT.getState()));
    const todayD = todayIso();

    const hk = $("homeKpis");
    if(hk){
      const cToday = completionForDate(parseISO(todayD), "all");
      const baseline = state.settings?.mvd?.habitsToHit ?? 4;
      const baselineHit = cToday.done >= baseline;
      hk.innerHTML = `
        <div class="box"><b>${baseline}</b><span>Baseline habits</span></div>
        <div class="box"><b>${cToday.done}/${cToday.total}</b><span>Completed today</span></div>
        <div class="box"><b>${baselineHit ? "Yes" : "No"}</b><span>Baseline hit</span></div>
      `;
    }

    const anchors = $("baselineAnchors");
    if(anchors){
      anchors.innerHTML = "";
      const pillars = state.settings?.mvd?.pillars || [];
      if(pillars.length===0){
        const n=document.createElement("div");
        n.className="notice";
        n.textContent = "Set your Baseline Day pillars in Settings → Baseline Day (e.g., Physical, Spiritual, Career).";
        anchors.appendChild(n);
      } else {
        for(const pid of pillars){
          const catObj = state.categories.find(c=>c.id===pid);
          const name = catObj ? catObj.name : pid;
          const log = state.logs?.[todayD];
          const habits = state.habits.filter(h=>h.categoryId===pid);
          let done = 0;
          for(const h of habits){ if(log?.checks?.[h.id]) done++; }
          const item=document.createElement("div");
          item.className="item";
          item.innerHTML = `<div><h3>${name}</h3><div class="meta">${done>0 ? "Done today" : "Not yet"}</div></div><div class="right"><span class="tag">${done>0 ? "hit" : "pending"}</span></div>`;
          item.addEventListener("click", ()=> activateTab("habits"));
          anchors.appendChild(item);
        }
      }
    }

    $("btnHomePlan")?.addEventListener("click", ()=>{ activateTab("coach"); });
    $("btnHomeCopy")?.addEventListener("click", ()=>{
      const cToday = completionForDate(parseISO(todayD), "all");
      const baseline = state.settings?.mvd?.habitsToHit ?? 4;
      const txt = `Baseline day: ${baseline} habits
Completed today: ${cToday.done}/${cToday.total}`;
      setClipboard(txt);
      alert("Copied.");
    });

    window.LCT.setState(state);
  }


  function renderAlchemyForToday(){ /* removed */ }


  // Update render when tabs clicked
  document.querySelectorAll(".tab").forEach(t=>{
    t.addEventListener("click", ()=>{
      const tab = t.dataset.tab;
      if(tab==="review") renderReviewTab();
      if(tab==="coach") renderCoachTab();
      if(tab==="todo") renderTodo();
      if(tab==="dashboard") renderHomeOS();
      if(tab==="settings") renderBaselineEditor();
      if(tab==="systems") renderSystemsTab();
    });
  });

  // Initial fill if user opens review tab first

  // Bind More section tiles
  document.querySelectorAll("#more .item[data-goto]").forEach(it=>{
    it.addEventListener("click", ()=>{
      const t = it.dataset.goto;
      activateTab(t);
      window.scrollTo({top:0, behavior:"smooth"});
    });
  });

  renderReviewTab();
  renderCoachTab();
  renderHomeOS();
  renderBaselineEditor();
  renderAlchemyForToday();

})();



// PWA: register service worker (works when served over http(s); not from file://)
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js').catch(()=>{});
  });
}
