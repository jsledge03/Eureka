# Life Compass Tracker

A local-first, offline-capable habit and goal tracking app built around
**MECE life categories** (Mutually Exclusive, Collectively Exhaustive).

## Features
- Year-long GitHub-style heatmap
- MECE life domains (editable)
- Goals → habits → daily check-offs
- Notes + reflection
- Insights & adjustment levers
- LocalStorage persistence
- Export / Import JSON backups

## How to Use
1. Open `index.html` in any modern browser (Chrome, Safari, Edge).
2. No login required. Works offline.
3. Your data stays on your device unless you export it.

## Tips
- Start with a small number of habits (6–10).
- Define a **minimum viable day**.
- Optimize for trends, not perfection.

Built for holistic, systems-based living.