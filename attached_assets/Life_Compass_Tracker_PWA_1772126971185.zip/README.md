# Life Compass Tracker (PWA)

A local-first, offline-capable habit and goal tracking app built around
**MECE life categories** (Mutually Exclusive, Collectively Exhaustive).

## What’s New in this PWA version
- Installable **PWA** (Android + iOS “Add to Home Screen”)
- Weekly Review flow (Reality → Meaning → Levers → Commit)
- Annual Review flow
- Coach Mode (interprets your data on-device and suggests next steps)
- “Reflection Packet” export to paste into your Custom GPT for planning

## Important: how PWAs work
Service workers (offline + install) require the app to be served over **http(s)**.
Opening `index.html` directly via `file://` will work as a normal webpage, but PWA install/offline may not.

### Fast ways to serve it
**Option A: VS Code Live Server**
1. Open the folder in VS Code
2. Install “Live Server” extension
3. Right click `index.html` → “Open with Live Server”

**Option B: Python (built-in)**
From the app folder, run:
- macOS/Linux: `python3 -m http.server 8080`
- Windows: `py -m http.server 8080`

Then open: `http://localhost:8080`

## Install (Add to Home Screen)
### iOS (Safari)
1. Open the app in **Safari** (must be served, see above)
2. Share button → **Add to Home Screen**
3. Launch from home screen (standalone)

### Android (Chrome)
1. Open the app in Chrome
2. Menu → **Install app** (or “Add to Home screen”)

## Data & Privacy
- Your data stays on your device in `localStorage`
- Use **Settings → Export** to back up as JSON
- Use **Settings → Import** to restore

## Weekly Review (recommended)
Go to **Review → Weekly Review** and answer the prompts.
Coach Mode will use these optional inputs to better calibrate recovery + complexity.

## Custom GPT “Sync”
This app cannot call your Custom GPT directly from the browser.
Instead, it generates a structured **Reflection Packet**:
- Review → “Export reflection packet”
- Copy/paste into your Custom GPT for turn-key reflection + planning.

Built for holistic, systems-based living.